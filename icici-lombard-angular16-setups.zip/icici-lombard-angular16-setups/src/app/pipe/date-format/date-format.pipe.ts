import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'ddMMMyyyy'
})
export class DateFormatPipe implements PipeTransform {

  transform(value: any): string {
    if (!value)
      return '';
    let date = new Date(value)
    let months = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]
    return `${date.getDate()}${this.nth(date.getDate())} ${months[date.getMonth()]} ${date.getFullYear()}`;
  }

  nth(d) {
    if (d > 3 && d < 21) return 'th';
    switch (d % 10) {
      case 1: return "st";
      case 2: return "nd";
      case 3: return "rd";
      default: return "th";
    }
  }
}
