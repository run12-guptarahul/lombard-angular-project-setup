import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { IndianCurrencyPipe } from './indian-currency/indian-currency.pipe';
import { NumberToLakhPipe, NumberToWordPipe } from './number-to-word/number-to-word.pipe';
import { DateFormatPipe } from './date-format/date-format.pipe';



@NgModule({
  declarations: [
    IndianCurrencyPipe,
    NumberToWordPipe,
    NumberToLakhPipe,
    DateFormatPipe
  ],
  imports: [
    CommonModule
  ],
  exports:[
    IndianCurrencyPipe,
    NumberToWordPipe,
    NumberToLakhPipe,
    DateFormatPipe

  ]
})
export class PipeModule { }
