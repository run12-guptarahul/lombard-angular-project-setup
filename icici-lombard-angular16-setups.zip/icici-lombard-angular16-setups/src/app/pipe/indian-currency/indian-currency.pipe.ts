import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'indianCurrency'
})
export class IndianCurrencyPipe implements PipeTransform {

  transform(value: any): any {
    let val = value;
    if (typeof val !== 'number') {
      val = val;
    }
    // Get the fractional part
    const fractionalPart = val % 1;

    // If fractional part is .5 or higher, round up to the next integer
    if (fractionalPart >= 0.5) {
      val = Math.ceil(val);
    } else {
      // If fractional part is less than .5, round down to the nearest integer
      val = Math.floor(val);
    }

    // Handle negative prices
    let prefix = '';
    if (val < 0) {
      prefix = '- ';
      val = Math.abs(val);
    }

    val = val.toString().replace(/,/g, '');
    return prefix + "₹" + new Intl.NumberFormat('en-IN', {
      /* style: 'currency',*/
      currency: 'INR',
      minimumFractionDigits: 0,
    }).format(Number(val));
  }

}
