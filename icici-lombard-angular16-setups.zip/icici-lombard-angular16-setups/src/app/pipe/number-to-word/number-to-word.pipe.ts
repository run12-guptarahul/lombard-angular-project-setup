import { Pipe, PipeTransform } from '@angular/core';

@Pipe({
  name: 'numberToWord'
})
export class NumberToWordPipe implements PipeTransform {
  transform(value: any): string {
    const numberValue = +value;
    if (numberValue >= 10000000) {
      return (numberValue / 10000000) + ' Crore';
    } else if (numberValue >= 100000) {
      return (numberValue / 100000) + ' lakhs';
    }
    return value;
  }
}

@Pipe({
  name: 'numberToLakh'
})
export class NumberToLakhPipe implements PipeTransform {

  transform(value: any): string {
    const numberValue = +value;
    if (numberValue >= 10000000) {
      return (numberValue / 10000000) + ' Crore';
    } else if (numberValue >= 100000) {
      return (numberValue / 100000) + ' lakhs';
    }
    return value;
  }

}
