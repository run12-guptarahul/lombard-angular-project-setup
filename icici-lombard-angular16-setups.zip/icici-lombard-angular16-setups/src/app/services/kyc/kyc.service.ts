import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { KycModel } from 'src/app/models/kyc-detail/kyc-model.model';

@Injectable({
  providedIn: 'root'
})
export class KycService {

  constructor() { }
  private dataSubject = new BehaviorSubject<KycModel>(new KycModel());
  kycdata$ = this.dataSubject.asObservable();

  setKycData(value: any) {
    this.dataSubject.next(value);
  }
}
