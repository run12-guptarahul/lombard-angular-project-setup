import { Injectable } from "@angular/core";
import { HttpInterceptor, HttpRequest, HttpHandler, HttpErrorResponse, HttpEvent } from "@angular/common/http";
import { eChannelConfig } from "src/app/constant/configuration";
import { catchError, from, throwError } from 'rxjs';
import { TokenServiceService } from "src/app/services/token/token-service.service";
import { Utility } from "src/app/constant/utility";
import { NETWORK_STATUS_CODE, NO_ENCRYPTION, SHOW_NETWORK_ERROR } from "src/app/constant/constants";
import { PopupService } from "src/app/services/popup/popup.service";


@Injectable()
export class RequestInterceptor implements HttpInterceptor {

  constructor(
    private _tokenService: TokenServiceService,
    private _popupService: PopupService
  ) { }

  intercept(req: HttpRequest<any>, next: HttpHandler): any {
    return from(this.handle(req, next));
  }

  async handle(req: HttpRequest<any>, next: HttpHandler): Promise<HttpEvent<any>> {
    let token = await this._tokenService.getToken();

    let newHeaders = req.headers;
    let newBody = req.body;

    newHeaders = newHeaders.append("Content-Type", "application/json");
    newHeaders = newHeaders.append("GclId", "" + eChannelConfig.gclId);
    newHeaders = newHeaders.append("EfId", "" + eChannelConfig.efId);
    newHeaders = newHeaders.append("ClientIPAddress", Utility.getClientIPAddress());
    newHeaders = newHeaders.append("DeviceId", Utility.getDeviceId());
    newHeaders = newHeaders.append("corelationid", Utility.getCorelationId());
    newHeaders = newHeaders.append("Version", Utility.version());
    newHeaders = newHeaders.append("ApiBinding", Utility.getApiBinding());
    if (token && newHeaders.get("Authorization") == null) {
      newHeaders = newHeaders.append("Authorization", "Bearer " + token);
    }

    var kv = Utility.getkvr();
    if (req.method.toLowerCase() === 'post') {
      if (req.headers.get(NO_ENCRYPTION) != 'true') {
        if (kv != undefined && kv != null && kv != "") {
          var enBody = Utility.getEncryptedBody(newBody, kv);
          newBody = enBody;

          kv = Utility.createEncryptedKV(kv);
          newHeaders = newHeaders.append("kv", kv);
        }
      }
    }

    const authReq = req.clone({ headers: newHeaders, body: newBody });

    return next.handle(authReq).pipe(
      catchError((error: HttpErrorResponse) => {
        let showNetworkError = authReq.headers.get(SHOW_NETWORK_ERROR);
        if (showNetworkError == "false")
          return null;
        let statusCode = NETWORK_STATUS_CODE;
        if (!Utility.IsNullOrEmpty(statusCode)) {
          let i = statusCode.split(",").findIndex(x=> { return Number(x) == error.status });
          if (i > -1) {
            let message ="";
            if (error.status == 400) {
              message = error.error.DisplayMessage;
            } else {
              message = error.status.toString() + " " + error.statusText;
            }
            this._popupService.openGenericErrorPopup(message);
          }
        }
        return throwError(() => error);
      })
    ).toPromise();
  }

}
