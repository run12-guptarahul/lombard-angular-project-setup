import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class GTMService {
  
  constructor() { }

  pushCustomGAEvent(eventName: string, eventCategory: string, eventAction: string, eventLabel: string) {
    try {
      if ((window as any)['dataLayer'] === undefined) {
        (window as any)['dataLayer'] = (window as any)['dataLayer'] || [];
      }
      const data = {
        'event': eventName,
        'eventCategory': eventCategory,
        'eventAction': eventAction,
        'eventLabel': eventLabel === '' || eventLabel === undefined ? 'NA' : eventLabel
      };

      (window as any)['dataLayer'].push(data);
      console.log((window as any)['dataLayer']);
    } catch (err) {
      (window as any)['dataLayer'].push({ 'event': 'errorpopup', 'statusmessage': err.message });
    }
  }

}
