import { TestBed } from '@angular/core/testing';

import { RestService } from './rest.service';

describe('RestService', () => {
  beforeEach(() => TestBed.configureTestingModule({
    providers: [
      RestService
    ]
  }));

  it('should be created', () => {
    const interceptor: RestService = TestBed.inject(RestService);
    expect(interceptor).toBeTruthy();
  });
});
