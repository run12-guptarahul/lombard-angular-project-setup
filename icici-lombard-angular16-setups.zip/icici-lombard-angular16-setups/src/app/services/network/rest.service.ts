import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { catchError, lastValueFrom, map, Observable, throwError } from 'rxjs';
import { eChannelConfig } from 'src/app/constant/configuration';
import { CreateCustomerRequestModel, GetCustomerRequestModel } from 'src/app/models/insured-page/customer/create-customer-request-model';
import { CreateCustomerResponseModel } from 'src/app/models/insured-page/customer/create-customer-response-model';
import { PincodeResponseModel } from 'src/app/models/insured-page/pincode/pincode-response-model';
import { ZoneRequestModel, ZoneResponseModel } from 'src/app/models/insured-page/pincode/zone-response-model';
import { FetchProposalRequestModel } from 'src/app/models/insured-page/proposal/fetch-proposal-request-model';
import { FetchProposalResponseModel } from 'src/app/models/insured-page/proposal/fetch-proposal-response-model';
import { ProposalRequestModel } from 'src/app/models/insured-page/proposal/proposal-request-model';
import { ProposalResponseModel } from 'src/app/models/insured-page/proposal/proposal-response-model';
import { RelationshipWithApplicantResponseModel } from 'src/app/models/insured-page/relationship/relationship-with-applicant-response-model';
import { RelationshipWithNomineeResponseModel } from 'src/app/models/insured-page/relationship/relationship-with-nominee-response-model';
import { CountryMasterResponseModel } from 'src/app/models/plan-page/country/country-master-response-model';
import { PlanMasterCover } from 'src/app/models/plan-page/premium/plans/plan-master-cover/plan-master-cover';

import { PlanPackageRequestModel } from 'src/app/models/plan-page/premium/plans/plan-package/plan-package-request-model';
import { PlanPackageResponseModel } from 'src/app/models/plan-page/premium/plans/plan-package/plan-package-response-model';
import { PremiumRequestModel } from 'src/app/models/plan-page/premium/premium/premium-request-model';
import { PremiumResponseModel } from 'src/app/models/plan-page/premium/premium/premium-response-model';
import { QuoteRequestModel } from 'src/app/models/plan-page/quote/quote-request-model';
import { LoginUIResponseModel } from 'src/app/models/token/token-response-model';
import { LoginRequestModel } from '../../models/plan-page/login-user/login-request-model';
import { LoginResponseModel } from '../../models/plan-page/login-user/login-response-model';
import { OtpRequestModel } from '../../models/plan-page/otp/otp-request-model';
import { OtpResponseModel } from '../../models/plan-page/otp/otp-response-model';
import { PedListModel } from 'src/app/models/insured-page/ped/ped-list-model';
import { FetchKycCustomerResponseModel } from 'src/app/models/insured-page/customer/fetch-customer-kyc-response-model';

@Injectable({
  providedIn: 'root'
})
export class RestService {

  constructor(private _http: HttpClient) { }

  getCityDistrictByPincode(pincode: string): Observable<any> {
    return this._http.get<any>('/eChannelServices/api/Master/CityDistrict/PinCode/' + pincode);
  }

  getCityDistrictByPin(pincode: string): Promise<PincodeResponseModel> {
    return lastValueFrom(
      this._http.get(eChannelConfig.PINCODE_URL + pincode)
        .pipe(map((response) => PincodeResponseModel.withAPIData(response))))
  }

  getMasterCover(): Promise<any> {
    return lastValueFrom(
      this._http.get(eChannelConfig.PLAN_MASTER_COVER_LIST)
        .pipe(
          catchError(error => {
            return throwError(error); // rethrow the error after logging it
          })
        )
    );
  }

  getMasterCountry(): Promise<any> {
    return lastValueFrom(
      this._http.get(eChannelConfig.PLAN_COUNTRY_LIST)
        .pipe(
          catchError(error => {
            return throwError(error); // rethrow the error after logging it
          })
        )
    );
  }
  
  Plans(request: PlanPackageRequestModel): Promise<PlanPackageResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.PLANS_URL, request)
        .pipe(map((response) => PlanPackageResponseModel.withAPIData(response))));
  }

  calculatePremium(request: PremiumRequestModel): Promise<PremiumResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.CALCULATE_PREMIUM_URL, request)
        .pipe(map((response) => PremiumResponseModel.withAPIData(response))));
  }

  fetchQuote(quoteRequestModel: QuoteRequestModel): Promise<PremiumResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.FETCH_QUOTE_URL,quoteRequestModel)
        .pipe(map((response) => PremiumResponseModel.withAPIData(response))));
  }

  buyNow(request: PremiumRequestModel): Promise<PremiumResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.CALCULATE_PREMIUM_URL, request)
        .pipe(map((response) => PremiumResponseModel.withAPIData(response))));
  }
  
  guestUserToken(request: any): Promise<LoginUIResponseModel> {
    return lastValueFrom(this._http
      .post(eChannelConfig.GUEST_TOKEN_URL, request)
      .pipe(map((response) => LoginUIResponseModel.withAPIData(response))));
  }

  fetchProposal(request: FetchProposalRequestModel): Promise<FetchProposalResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.FETCH_PROPOSAL_URL, request)
        .pipe(map((response) => FetchProposalResponseModel.withAPIData(response))));
  }

  saveProposal(request: ProposalRequestModel): Promise<ProposalResponseModel> {
    console.log(JSON.parse(JSON.stringify(request)));
    return lastValueFrom(
      this._http.post(eChannelConfig.SAVE_PROPOSAL_URL, request)
        .pipe(map((response) => ProposalResponseModel.withAPIData(response))));
  }

  getCustomerDetails(request: GetCustomerRequestModel): Promise<FetchKycCustomerResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.GET_CUSTOMER_KYC_URL, request)
        .pipe(map((response) => FetchKycCustomerResponseModel.withAPIData(response))));
  }

  createCustomer(request: CreateCustomerRequestModel): Promise<CreateCustomerResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.CREATE_CUSTOMER_URL, request)
        .pipe(map((response) => CreateCustomerResponseModel.withAPIData(response))));
  }

  getPEDList(): Promise<PedListModel> {
    return lastValueFrom(this._http
      .get(eChannelConfig.GET_PED_LIST)
      .pipe(map((response) => PedListModel.withAPIData(response))));
  }

  getRelationshipWithApplicant(): Promise<RelationshipWithApplicantResponseModel> {
    return lastValueFrom(
      this._http.get(eChannelConfig.GET_RELATIONSHIP_WITH_APPLICANT_URL)
        .pipe(map((response) => RelationshipWithApplicantResponseModel.withAPIData(response)),

          catchError(error => {
            return throwError(error); // rethrow the error after logging it
          })
        )
    );
  }

  getRelationshipWithNominee(): Promise<RelationshipWithNomineeResponseModel> {
    return lastValueFrom(
      this._http.get(eChannelConfig.GET_RELATIONSHIP_WITH_NOMINEE_URL)
        .pipe( map((response) => RelationshipWithNomineeResponseModel.withAPIData(response)),
          catchError(error => {
            return throwError(error); // rethrow the error after logging it
          })
        )
    );
  }


  mobileVerify(request: LoginRequestModel): Promise<LoginResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.LOGIN_USER_URL, request)
        .pipe(map((response) => LoginResponseModel.withAPIData(response))));
  }

  verifyOTP(request: OtpRequestModel): Promise<OtpResponseModel> {
    return lastValueFrom(
      this._http.post(eChannelConfig.VERIFY_OTP_URL, request)
        .pipe(map((response) => OtpResponseModel.withAPIData(response))));
  }
}
