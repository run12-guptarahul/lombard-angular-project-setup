import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HttpErrorResponse } from '@angular/common/http';
import { AddonKnowMorePopupModel, AttentionPopupModel, BenefitPopupModel, GenericPopupModel, ComparePlanPopupModel } from 'src/app/models/common-model.model';
import { Utility } from 'src/app/constant/utility';

@Injectable({
  providedIn: 'root'
})
export class PopupService {
  genericPopupModel: GenericPopupModel = new GenericPopupModel();
  benefitPopupModel: BenefitPopupModel = new BenefitPopupModel();
  comparePlanPopupModel: ComparePlanPopupModel = new ComparePlanPopupModel();
  addonKnowMorePopupModel: AddonKnowMorePopupModel = new AddonKnowMorePopupModel();
  attentionPopupModel: AttentionPopupModel = new AttentionPopupModel();
  constructor() { }


  public isGenericErrorPopup: BehaviorSubject<GenericPopupModel> = new BehaviorSubject(null);
  public isBenefitCoverPopup: BehaviorSubject<BenefitPopupModel> = new BehaviorSubject(null);
  public isComparePopup: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public isOTPPopup: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public isPedPopup = new BehaviorSubject<[any, [], boolean]>([null, [], false]);
  public isAddonKnowMorePopup: BehaviorSubject<AddonKnowMorePopupModel> = new BehaviorSubject(null);
  public isPremiumSummaryPopup: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public isPremiumDetailsPopup: BehaviorSubject<boolean> = new BehaviorSubject(false);
  public isPlanDetailsPopup = new BehaviorSubject(null);
  public isPepPopup = new BehaviorSubject(null);
  public isAttentionPopup = new BehaviorSubject(null);
  public isPedInfoPopup = new BehaviorSubject(null);

  openGenericErrorPopup(message: string, isRedirection: boolean = false,
    redirectionUrl?: string, error?: HttpErrorResponse) {
    this.genericPopupModel.errorMessage = (!Utility.IsNullOrEmpty(message) ? message :
      !Utility.IsNullOrEmpty(error?.message) ? error.message : "something went wrong");
    this.genericPopupModel.isRedirection = isRedirection;
    this.genericPopupModel.redirectURL = redirectionUrl;
    this.genericPopupModel.errorResponse = error;
    this.genericPopupModel.showPopup = true;
    this.isGenericErrorPopup.next(this.genericPopupModel);
  }

  closeGenericErrorPopup() {
    this.genericPopupModel.showPopup = false;
    this.isGenericErrorPopup.next(this.genericPopupModel);
  }

  openBenefitCoverPopup(data:any){
    this.benefitPopupModel.cover = data;
    this.benefitPopupModel.showPopup = true;
    this.isBenefitCoverPopup.next(this.benefitPopupModel);
  }
  closeBenefitCoverPopup(){
    this.benefitPopupModel.showPopup = false;
    this.isBenefitCoverPopup.next(this.benefitPopupModel);
  }
  openComparePlanPopup() {
    this.isComparePopup.next(true);
  }
  closeComparePlanPopup() {
    this.isComparePopup.next(false);
  }
  openAddonKnowMorePopup(data:any,index:number,isSelected:boolean){
    this.addonKnowMorePopupModel.cover = data;
    this.addonKnowMorePopupModel.showPopup = true;
    this.addonKnowMorePopupModel.coverIndex = index;
    this.addonKnowMorePopupModel.isSelected = isSelected;
    this.isAddonKnowMorePopup.next(this.addonKnowMorePopupModel);
  }
  closeAddonKnowMorePopup(){
    this.addonKnowMorePopupModel.showPopup = false;
    this.isAddonKnowMorePopup.next(this.addonKnowMorePopupModel);
  }

  openPremiumSummaryPopup(){
    this.isPremiumSummaryPopup.next(true);
  }
  closePremiumSummaryPopup(){
    this.isPremiumSummaryPopup.next(false);
  }

  openPremiumDetailsPopup(){
    this.isPremiumDetailsPopup.next(true);
  }
  closePremiumDetailsPopup(){
    this.isPremiumDetailsPopup.next(false);
  }

  openPlanDetailsPopUp() {
    this.isPlanDetailsPopup.next(true);
  }

  closePlanDetailsPopUp() {
    this.isPlanDetailsPopup.next(false);
  }

  openPepPopUp() {
    this.isPepPopup.next(true);
  }

  closePepPopUp() {
    this.isPepPopup.next(false);
  }

  openPedPopup(index: any, pedCode: any, flag: boolean) {
    this.isPedPopup.next([index, pedCode, flag]);
  }

  closePedPopup() {
    // this.isPedPopup.next(false);
  }

  openPedInfoPopup() {
    this.isPedInfoPopup.next(true);
  }
  closePedInfoPopup() {
    this.isPedInfoPopup.next(false);
  }

  openAttentionPopup(heading: string, info1: string, info2: string, isShowPopup: boolean, btn1: boolean, btn2: boolean) {
    this.attentionPopupModel.heading = heading;
    this.attentionPopupModel.info1 = info1;
    this.attentionPopupModel.info2 = info2;
    this.attentionPopupModel.isShowPopup = isShowPopup;
    this.attentionPopupModel.btn1 = btn1;
    this.attentionPopupModel.btn2 = btn2;
    this.isAttentionPopup.next(this.attentionPopupModel);
  }

  closeAttentionPopup() {
    this.attentionPopupModel.isShowPopup = false;
    this.isAttentionPopup.next(this.attentionPopupModel);
  }

  openOTPPopup() {
    this.isOTPPopup.next(true);
  }

  closeOTPPopup() {
    this.isOTPPopup.next(false);
  }

}
