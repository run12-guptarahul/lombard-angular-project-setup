import { TestBed } from '@angular/core/testing';

import { RNSubscriberService } from './rn-subscriber.service';

describe('PlanSubscriberService', () => {
  let service: RNSubscriberService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RNSubscriberService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
