import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable } from 'rxjs';
import { PlanUIModel } from 'src/app/models/plan-page/plan-ui-model';

@Injectable({
  providedIn: 'root'
})
export class RNSubscriberService {

  
}
