import { Injectable } from "@angular/core";
import { HttpClient, HttpBackend, HttpHeaders } from "@angular/common/http";
import { eChannelConfig } from "src/app/constant/configuration";
import { environment } from "src/app/environments/environment";
import { Utility } from "src/app/constant/utility";
import { lastValueFrom, map } from "rxjs";
import { LoginUIResponseModel } from "src/app/models/token/token-response-model";
import { AUTH_TOKEN, AUTH_TOKEN_EXPIRY, CORELATION_ID, TOKEN_ID } from "src/app/constant/constants";


@Injectable({
  providedIn: "root",
})
export class TokenServiceService {

  private _http: HttpClient;

  readonly client = environment.Client;
  readonly scope = environment.Scope;
  loginUIResponseModel: LoginUIResponseModel = new LoginUIResponseModel();

  constructor(handler: HttpBackend) {
    this._http = new HttpClient(handler);
  }

  async getToken() {
    let token = "";
    var ret = this.isAuthTokenExpired();
    if (ret == "GetAuthToken") {
      sessionStorage.removeItem(CORELATION_ID);
      await this.generateAuthToken().then((res) => {
        if (res.success)
          this.setTokenValues(res);
      });
    } else if (ret == "GetRefreshToken") {
      await this.refreshAuthToken().then((res) => {
        if (res.success)
          this.setTokenValues(res);
      });
    }
    token = Utility.retrieveSessionData(AUTH_TOKEN);
    return token;
  }

  setTokenValues(response: LoginUIResponseModel) {
    if (!Utility.IsNullOrEmpty(response) && response.success) {
      sessionStorage.setItem(AUTH_TOKEN, response.authToken);
      sessionStorage.setItem(AUTH_TOKEN_EXPIRY, new Date(response.tokenExpiry).toString());
      //sessionStorage.setItem(IS_PROPOSAL_OTP_AUTH, response.isProposalOTPAuth.toString().toLowerCase());
    }
  }

  isAuthTokenExpired() {
    let token = Utility.retrieveSessionData(AUTH_TOKEN);
    if (!Utility.IsNullOrEmpty(token)) {
      let tokenExpiry = Utility.retrieveSessionData(AUTH_TOKEN_EXPIRY);
      let tokenExpiryDateTime = new Date(tokenExpiry);
      let currentDateTime = new Date();
      let ret = 60 * 1000;
      ret = (+tokenExpiryDateTime - +currentDateTime) / ret;
      if (ret < 2 && ret > 0) { return "GetRefreshToken"; }
      else if (ret < 0) { return "GetAuthToken"; }
      else { return "NotExpired"; }
    } else { return "GetAuthToken"; }
  };

  async refreshAuthToken(): Promise<LoginUIResponseModel> {
    this.loginUIResponseModel = await this.makePostCallForAuthToken(eChannelConfig.REFRESH_URL, "");
    return this.loginUIResponseModel;
  }

  async generateAuthToken(): Promise<LoginUIResponseModel> {
    const data = {
      Client: this.client,
      Scope: this.scope,
    };
    let TokenId = Utility.GetUrlParameter(TOKEN_ID);
    if (!Utility.IsNullOrEmpty(TokenId))
      this.loginUIResponseModel = await this.makeGetCallForAuthToken(eChannelConfig.WEB_TOKEN_URL + TokenId);
    else
      this.loginUIResponseModel = await this.makePostCallForAuthToken(eChannelConfig.AUTH_URL, data);
    return this.loginUIResponseModel;
  }

  makePostCallForAuthToken(url: string, data: any): Promise<LoginUIResponseModel> {
    let token = Utility.retrieveSessionData(AUTH_TOKEN);
    let kv = Utility.getkvr();
    let body = Utility.getEncryptedBody(data, kv);
    kv = Utility.createEncryptedKV(kv);
    let headers = new HttpHeaders()
      .set("Content-Type", "application/json")
      .set("ClientIPAddress", Utility.getClientIPAddress())
      .set("DeviceId", Utility.getDeviceId())
      .set("CorelationId", Utility.getCorelationId())
      .set('version', 'v6.1.1')
      .set('ApiBinding', Utility.getApiBinding())
      .set('kv', kv)
    if (!Utility.IsNullOrEmpty(token))
      headers = headers.append("Authorization", "Bearer " + token);
    else
      headers = headers.append("Authorization", "Bearer ");

    let options = { headers: headers };
    return lastValueFrom(this._http.post(url, body, options)
      .pipe(map((response) => LoginUIResponseModel.withAPIData(response))));
  }

  makeGetCallForAuthToken(url: string): Promise<LoginUIResponseModel> {
    let token = Utility.retrieveSessionData(AUTH_TOKEN);
    let headers = new HttpHeaders()
      .set("Content-Type", "application/json")
      .set("ClientIPAddress", Utility.getClientIPAddress())
      .set("DeviceId", Utility.getDeviceId())
      .set("CorelationId", Utility.getCorelationId())

    if (!Utility.IsNullOrEmpty(token))
      headers = headers.append("Authorization", "Bearer " + token);
    else
      headers = headers.append("Authorization", "Bearer " + null);

    let options = { headers: headers };
    return lastValueFrom(this._http.get(url, options)
      .pipe(map((response) => LoginUIResponseModel.withAPIData(response))));
  }
}
