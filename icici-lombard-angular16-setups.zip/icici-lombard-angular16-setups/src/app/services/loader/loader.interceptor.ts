import { Injectable } from '@angular/core';
import { HttpRequest, HttpHandler, HttpEvent, HttpInterceptor, HttpResponse } from '@angular/common/http';
import { Observable, finalize } from 'rxjs';
import { CommonService } from 'src/app/services/common/common.service';
import { NO_LOADER } from 'src/app/constant/constants';

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {

  private requests: HttpRequest<any>[] = [];

  constructor(
    private _commonService: CommonService
  ) { }


  removeRequest(req: HttpRequest<any>) {
    if (req.headers.get(NO_LOADER) != 'true') {
      const i = this.requests.indexOf(req);
      if (i > -1) {
        this.requests.splice(i, 1);
      }
      this._commonService.isLoader.next(this.requests.length > 0);
    }
  }

  intercept(req: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    if (req.headers.get(NO_LOADER) != 'true') {
      this.requests.push(req);
      this._commonService.isLoader.next(true);
    }

    return Observable.create(observer => {
      const subscription = next.handle(req)
        .subscribe(
          event => {
            if (event instanceof HttpResponse) {
              this.removeRequest(req);
              observer.next(event);
            }
          },
          err => {
            this.removeRequest(req);
            observer.error(err);
          },
          () => {
            this.removeRequest(req);
            observer.complete();
          });
      // remove request from queue when cancelled
      return () => {
        this.removeRequest(req);
        subscription.unsubscribe();
      };
    });
  }
}
