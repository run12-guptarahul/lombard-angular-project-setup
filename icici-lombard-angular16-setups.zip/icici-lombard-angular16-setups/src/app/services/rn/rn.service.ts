import { Injectable } from '@angular/core';
import { PremiumRequestModel } from 'src/app/models/plan-page/premium/premium/premium-request-model';
import { PremiumResponseModel } from 'src/app/models/plan-page/premium/premium/premium-response-model';
import { PlanPackageRequestModel } from 'src/app/models/plan-page/premium/plans/plan-package/plan-package-request-model';
import { PlanPackageResponseModel } from 'src/app/models/plan-page/premium/plans/plan-package/plan-package-response-model';
import { Subject, retry, takeUntil } from 'rxjs';


@Injectable({
  providedIn: 'root'
})
export class RNService {
  premiumRequestModel: PremiumRequestModel = new PremiumRequestModel();
  PremiumResponseModel: PremiumResponseModel;

  planRequestModel: PlanPackageRequestModel = new PlanPackageRequestModel();
  planResponseModel: PlanPackageResponseModel;

  unsubscribe$: Subject<boolean> = new Subject();
  constructor(
  ) {
  }

  

}





