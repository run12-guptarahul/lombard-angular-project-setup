import { TestBed } from '@angular/core/testing';

import { RNService } from './rn.service';

describe('PlanService', () => {
  let service: RNService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RNService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
