import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { LoaderComponent } from 'src/app/shared/loader/loader.component';
import { GenericErrorComponent } from 'src/app/shared/generic-error/generic-error.component';


@NgModule({
  declarations: [
    LoaderComponent,
    GenericErrorComponent,
  ],
  imports: [
    CommonModule
  ]
  ,
  exports:[
    LoaderComponent,
    GenericErrorComponent,
  ]

})
export class SharedModule { }
