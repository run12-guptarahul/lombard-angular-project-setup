import { Component } from '@angular/core';
import { CommonService } from 'src/app/services/common/common.service';
import { environment } from 'src/app/environments/environment';

declare var $: any;

@Component({
  selector: 'app-loader',
  templateUrl: './loader.component.html',
  styleUrls: ['./loader.component.css']
})
export class LoaderComponent {
  isLoader: boolean = true;
  readonly deployUrl = environment.deployUrl;
  constructor(
    private _commonService:CommonService
  )
  {
    this._commonService.isLoader.subscribe((data)=>{
      if(data != null && data !=undefined){
        this.isLoader = data;
       }
     })
  }

}
