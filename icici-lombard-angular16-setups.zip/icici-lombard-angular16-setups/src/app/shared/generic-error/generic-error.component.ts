import { Component } from '@angular/core';
import { environment } from 'src/app/environments/environment';
import { PopupService } from 'src/app/services/popup/popup.service';
import { Utility } from 'src/app/constant/utility';
import { GenericPopupModel } from 'src/app/models/common-model.model';

@Component({
  selector: 'app-generic-error',
  templateUrl: './generic-error.component.html',
  styleUrls: ['./generic-error.component.css']
})
export class GenericErrorComponent {

  readonly deployUrl = environment.deployUrl;
  genericPopupModel: GenericPopupModel = new GenericPopupModel();

  constructor(
    private _popupService: PopupService,
  ) {
    this._popupService.isGenericErrorPopup.subscribe((value) => {
      if (!Utility.IsNullOrEmpty(value))
        this.genericPopupModel = value;
    });
  }

  ngOnInit(): void {

  }

  closeErrorPopup() {
    this._popupService.closeGenericErrorPopup();
  }
}
