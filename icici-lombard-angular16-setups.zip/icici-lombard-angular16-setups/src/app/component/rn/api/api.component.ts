import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { RestService } from 'src/app/services/network/rest.service';
import * as CryptoJS from 'crypto-js';
import { eChannelConfig } from 'src/app/constant/configuration';

@Component({
  selector: 'app-api',
  templateUrl: './api.component.html',
  styleUrls: ['./api.component.css']
})

export class ApiComponent implements OnInit {
  pincodeForm:FormGroup;
  cityState:string;
  constructor(
    private _fb:FormBuilder,
    private _restService:RestService){
  }
  
  
  ngOnInit() {
    this.createForm();
    let UIData = window.sessionStorage.getItem('UIData') || '{}';
    let decryptData = this.decryptData(UIData);
  }
  
  createForm(){
    this.pincodeForm = this._fb.group({
      pincode : new FormControl('',Validators.required)
    })
  }
  //getter
  get formdata(){
    return this.pincodeForm.controls;
  }
  
  get pinCodeValue(){
    return this.formdata['pincode'].value;
  }
  
  submitPincodeForm(){
    if(this.pincodeForm.status.toLocaleLowerCase() == 'valid')
    {
    return this._restService.getCityDistrictByPincode(this.pinCodeValue).subscribe(
      data =>{
        this.cityState = data.cityDistrictName;
        let encryptData =  this.encryptData(this.cityState) || '';
        window.sessionStorage.setItem('UIData',encryptData);
      },
      err => {
        console.log(err)
      }
    );
  
    }
    else
    {
      alert('fail');
    }
  }
  encryptData(data:any) {
    try {
      return CryptoJS.AES.encrypt(JSON.stringify(data), eChannelConfig.CryptoKey).toString();
    } catch (e) {
      console.log(e);
    }
  }
  
  decryptData(data:any) {
    try {
      const bytes = CryptoJS.AES.decrypt(data, eChannelConfig.CryptoKey);
      if (bytes.toString()) {
        return JSON.parse(bytes.toString(CryptoJS.enc.Utf8));
      }
      return data;
    } catch (e) {
      console.log(e);
    }
  }
  
  }