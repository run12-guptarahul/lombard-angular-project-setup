import { Component } from '@angular/core';

@Component({
  selector: 'app-benefit-cover',
  templateUrl: './benefit-cover.component.html',
  styleUrls: ['./benefit-cover.component.css']
})
export class BenefitCoverComponent {

}
