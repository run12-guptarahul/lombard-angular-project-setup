import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuredDetailComponent } from './insured-detail.component';

describe('InsuredDetailComponent', () => {
  let component: InsuredDetailComponent;
  let fixture: ComponentFixture<InsuredDetailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InsuredDetailComponent]
    });
    fixture = TestBed.createComponent(InsuredDetailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
