import { Component } from '@angular/core';

@Component({
  selector: 'app-insured-detail',
  templateUrl: './insured-detail.component.html',
  styleUrls: ['./insured-detail.component.css']
})
export class InsuredDetailComponent {

}
