import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { SharedModule } from 'src/app/shared/shared.module';
import { DirectiveModule } from 'src/app/directive/directive.module';
import { PipeModule } from 'src/app/pipe/pipe.module';
import { RNComponent } from './rn.component';
import { ApiComponent } from './api/api.component';
import { PlanHeaderComponent } from './plan-header/plan-header.component';
import { SuminsuredComponent } from './suminsured/suminsured.component';
import { ZoneComponent } from './zone/zone.component';
import { BenefitCoverComponent } from './benefit-cover/benefit-cover.component';
import { AddonComponent } from './addon/addon.component';
import { IncludedAddonComponent } from './included-addon/included-addon.component';
import { PolicyDocumentComponent } from './policy-document/policy-document.component';
import { UinComponent } from './uin/uin.component';
import { CopayComponent } from './copay/copay.component';
import { InsuredDetailComponent } from './insured-detail/insured-detail.component';
import { InsuredMemberComponent } from './insured-member/insured-member.component';
import { ApplicantComponent } from './applicant/applicant.component';
import { NomineeComponent } from './nominee/nominee.component';
import { TaxDetailComponent } from './tax-detail/tax-detail.component';
import { PremiumSummaryComponent } from './premium-summary/premium-summary.component';
import { PremiumSummaryPopupComponent } from 'src/app/popup/premium-summary-popup/premium-summary-popup.component';
import { ComparePlanComponent } from 'src/app/popup/compare-plan/compare-plan.component';

@NgModule({
  declarations: [
    RNComponent,
    ApiComponent,
    PlanHeaderComponent,
    SuminsuredComponent,
    BenefitCoverComponent,
    CopayComponent,
    AddonComponent,
    IncludedAddonComponent,
    InsuredDetailComponent,
    InsuredMemberComponent,
    ApplicantComponent,
    NomineeComponent,
    TaxDetailComponent,
    UinComponent,
    ZoneComponent,
    PolicyDocumentComponent,
    ComparePlanComponent,
    PremiumSummaryPopupComponent,
  ],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    DirectiveModule,
    PipeModule
  ],
  exports:[
    RNComponent,
    ApiComponent,
    PlanHeaderComponent,
    SuminsuredComponent,
    BenefitCoverComponent,
    CopayComponent,
    AddonComponent,
    IncludedAddonComponent,
    InsuredDetailComponent,
    InsuredMemberComponent,
    ApplicantComponent,
    NomineeComponent,
    TaxDetailComponent,
    UinComponent,
    ZoneComponent,
    PolicyDocumentComponent,
    ComparePlanComponent,
    PremiumSummaryPopupComponent,

  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class RnModule { }
