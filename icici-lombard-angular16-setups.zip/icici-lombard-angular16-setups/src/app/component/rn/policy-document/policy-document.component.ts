import { Component } from '@angular/core';

@Component({
  selector: 'app-policy-document',
  templateUrl: './policy-document.component.html',
  styleUrls: ['./policy-document.component.css']
})
export class PolicyDocumentComponent {

}
