import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PolicyDocumentComponent } from './policy-document.component';

describe('PolicyDocumentComponent', () => {
  let component: PolicyDocumentComponent;
  let fixture: ComponentFixture<PolicyDocumentComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PolicyDocumentComponent]
    });
    fixture = TestBed.createComponent(PolicyDocumentComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
