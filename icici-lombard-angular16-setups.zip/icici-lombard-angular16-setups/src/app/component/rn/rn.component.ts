import { Component } from '@angular/core';

@Component({
  selector: 'app-rn',
  templateUrl: './rn.component.html',
  styleUrls: ['./rn.component.css']
})
export class RNComponent {

}
