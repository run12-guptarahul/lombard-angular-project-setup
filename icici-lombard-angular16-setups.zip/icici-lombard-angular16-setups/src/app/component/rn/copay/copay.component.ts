import { Component } from '@angular/core';

@Component({
  selector: 'app-copay',
  templateUrl: './copay.component.html',
  styleUrls: ['./copay.component.css']
})
export class CopayComponent {

}
