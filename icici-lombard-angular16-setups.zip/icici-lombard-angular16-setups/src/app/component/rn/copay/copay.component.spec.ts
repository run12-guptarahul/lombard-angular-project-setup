import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CopayComponent } from './copay.component';

describe('CopayComponent', () => {
  let component: CopayComponent;
  let fixture: ComponentFixture<CopayComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [CopayComponent]
    });
    fixture = TestBed.createComponent(CopayComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
