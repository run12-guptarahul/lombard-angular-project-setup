import { Component } from '@angular/core';

@Component({
  selector: 'app-included-addon',
  templateUrl: './included-addon.component.html',
  styleUrls: ['./included-addon.component.css']
})
export class IncludedAddonComponent {

}
