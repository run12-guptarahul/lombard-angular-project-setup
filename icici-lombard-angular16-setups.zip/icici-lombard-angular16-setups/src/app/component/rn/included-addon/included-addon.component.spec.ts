import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncludedAddonComponent } from './included-addon.component';

describe('IncludedAddonComponent', () => {
  let component: IncludedAddonComponent;
  let fixture: ComponentFixture<IncludedAddonComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IncludedAddonComponent]
    });
    fixture = TestBed.createComponent(IncludedAddonComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
