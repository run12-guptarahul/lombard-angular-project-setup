import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RNComponent } from './rn.component';

describe('RNComponent', () => {
  let component: RNComponent;
  let fixture: ComponentFixture<RNComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RNComponent]
    });
    fixture = TestBed.createComponent(RNComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
