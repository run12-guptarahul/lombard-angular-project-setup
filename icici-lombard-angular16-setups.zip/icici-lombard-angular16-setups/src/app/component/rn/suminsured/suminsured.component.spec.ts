import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuminsuredComponent } from './suminsured.component';

describe('SuminsuredComponent', () => {
  let component: SuminsuredComponent;
  let fixture: ComponentFixture<SuminsuredComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SuminsuredComponent]
    });
    fixture = TestBed.createComponent(SuminsuredComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
