import { Component } from '@angular/core';

@Component({
  selector: 'app-suminsured',
  templateUrl: './suminsured.component.html',
  styleUrls: ['./suminsured.component.css']
})
export class SuminsuredComponent {

}
