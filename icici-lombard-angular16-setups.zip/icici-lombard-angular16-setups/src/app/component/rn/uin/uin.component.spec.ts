import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UinComponent } from './uin.component';

describe('UinComponent', () => {
  let component: UinComponent;
  let fixture: ComponentFixture<UinComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UinComponent]
    });
    fixture = TestBed.createComponent(UinComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
