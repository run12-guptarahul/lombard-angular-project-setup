import { Component } from '@angular/core';

@Component({
  selector: 'app-uin',
  templateUrl: './uin.component.html',
  styleUrls: ['./uin.component.css']
})
export class UinComponent {

}
