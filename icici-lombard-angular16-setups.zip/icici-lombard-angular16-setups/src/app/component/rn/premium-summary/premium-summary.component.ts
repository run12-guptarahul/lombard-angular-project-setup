import { Component } from '@angular/core';

@Component({
  selector: 'app-premium-summary',
  templateUrl: './premium-summary.component.html',
  styleUrls: ['./premium-summary.component.css']
})
export class PremiumSummaryComponent {

}
