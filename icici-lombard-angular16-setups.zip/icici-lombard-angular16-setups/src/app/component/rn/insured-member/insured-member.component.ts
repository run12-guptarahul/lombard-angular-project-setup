import { Component } from '@angular/core';

@Component({
  selector: 'app-insured-member',
  templateUrl: './insured-member.component.html',
  styleUrls: ['./insured-member.component.css']
})
export class InsuredMemberComponent {

}
