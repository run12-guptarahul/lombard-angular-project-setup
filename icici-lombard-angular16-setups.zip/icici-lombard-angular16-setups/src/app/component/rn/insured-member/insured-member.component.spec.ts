import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InsuredMemberComponent } from './insured-member.component';

describe('InsuredMemberComponent', () => {
  let component: InsuredMemberComponent;
  let fixture: ComponentFixture<InsuredMemberComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [InsuredMemberComponent]
    });
    fixture = TestBed.createComponent(InsuredMemberComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
