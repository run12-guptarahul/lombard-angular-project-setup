export const environment = {
  production: false,
  deployUrl: '/docs/default-source/apps/website-chirenewal-fresh-app/',
  Client: 'website',
  Scope: 'website',
  LoginType: 'App',
  PBK: '-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAp1C5CT6JJ4FswevuuaDP9cjp6k9G0Gg29wgLFywVLdTnHksjrVFS5TcmyOFu6oKqfuDe15jqTba12XDaWJORnfuqnPFiSxKnK1SZedzlrMpcFvfjfmOTNxXtQYYELfGXZr0JXqig+Zr23VYhgRGhdKZezzJEY5ZPUQ75YHX4IzwUeRTRKfGReDFHahGoY56Z0FlPRoFkrxVz/3wvtDWgPOyVXBHMSVe8jaOS5RHpw3sNm5aKR7ZGCRUBchxGY6bjF1oGcYHWnf/wgqkGjiBfpB7O6k3V3rLM4ZmOM+Ck83/8VrmuPbI1qIY6A27JDZDGHEC0EyVv1CEjwqYP1wUNTwIDAQAB-----END PUBLIC KEY-----',
 // Stage PBK: '-----BEGIN PUBLIC KEY-----MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAqJB60iVd+Thl+P5+Ore0abr7Ae+ANK+9jCj7UbYyXNSIbP6g3QMd4LhAAojln4VZRgpSBKjZ8YBc1yGgb516BOzfOBeqN4WtwN764UwFCyMaF0nA50BnjcMfGKLPvmhAbeRtaG06GtLhbAS9z57NQdEXivHzlRZJehzf7IHcpIUUDXKcaXe2/dHkAGk2zLhdrY9VErAxVj1g39qMNSvAJlrVT+heuR3MWwdle9KNgVFgg7AXybBhorb9GIuMsQS6UTxA/HIvSZUqAetDRfgGhTCss9Kq6EqJV92u4AiOIngstIOA3seLWx48N4xR0jfmZZElwlJIHeedgWxDsEN4/wIDAQAB-----END PUBLIC KEY-----'
};
