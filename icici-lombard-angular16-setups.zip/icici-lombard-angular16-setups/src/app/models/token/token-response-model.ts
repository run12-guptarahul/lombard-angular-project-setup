import { Utility } from "src/app/constant/utility";
import { BaseUIResponseModel } from "src/app/models/base/base-ui-response-model";

export class LoginUIResponseModel extends BaseUIResponseModel {

  authToken: string = "";
  clientIPAddress: string = "";
  clientIPAddressSource: string = "";
  clientId: number = 0;
  expiry: string = "";
  iPartnerUserId: number = 0;
  isGuestUser: boolean = false;
  lastLogin: string = "";
  token: string = "";
  tokenExpiry: string = "";
  userName: string = "";
  kv: string = "";
  SID: string = "";
  isProposalOTPAuth: boolean = false;

  protected override setData(res) {
    this.authToken = Utility.IsNullOrEmpty(res.Passcode) ? res.authToken : res.Passcode;
    this.clientId = 1;
    this.tokenExpiry = Utility.IsNullOrEmpty(res.Expiry) ? res.tokenExpiry : res.Expiry;
    this.isProposalOTPAuth = false;
    super.setData(res);
  }

  public static override withAPIData(res): LoginUIResponseModel {
    let obj = new LoginUIResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
}
export class EncryptedKvUIModel {
	public msg: any;
	constructor(msg: any) {
		this.msg = msg;
	}
}
