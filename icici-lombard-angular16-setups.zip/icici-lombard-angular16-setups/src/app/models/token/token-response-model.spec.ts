import { LoginUIResponseModel } from './token-response-model';

describe('LoginUIResponseModel', () => {
  it('should create an instance', () => {
    expect(new LoginUIResponseModel()).toBeTruthy();
  });
});
