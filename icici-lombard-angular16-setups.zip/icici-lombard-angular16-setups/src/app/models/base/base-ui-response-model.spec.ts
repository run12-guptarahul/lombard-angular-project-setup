import { BaseUiResponseModel } from './base-ui-response-model';

describe('BaseUiResponseModel', () => {
  it('should create an instance', () => {
    expect(new BaseUiResponseModel()).toBeTruthy();
  });
});
