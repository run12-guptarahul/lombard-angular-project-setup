export class BaseUIResponseModel {
  errorId: number;
  errorMessage : string;
  success: boolean;
  statusCode: number;
  technicalError?: string;
  displayMessage?: string;
  corelationId?: string;
  technicalErrorMessage?: string
  status?: string;

  protected setData(res: any) {
    this.errorId = res.errorId ? res.errorId : (res.ErrorId)? res.ErrorId :"";
    this.errorMessage = res.errorMessage ? res.errorMessage : (res.ErrorMessage) ? res.ErrorMessage : "";
    this.success = res.success ? res.success : (res.Success) ? res.Success : false;
    this.statusCode = res.statusCode ? res.statusCode :(res.StatusCode) ? res.StatusCode :"";
    this.technicalError = res.technicalErrorMessage ? res.technicalErrorMessage : (res.TechnicalErrorMessage) ? res.TechnicalErrorMessage : "";
    this.displayMessage = res.displayMessage ? res.displayMessage : (res.DisplayMessage) ? res.DisplayMessage : '';
    this.corelationId = res.corelationId ? res.corelationId : (res.CorelationId) ? res.CorelationId :'';
  }

  public static withAPIData(res: any): BaseUIResponseModel {
    let obj = new BaseUIResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
}
