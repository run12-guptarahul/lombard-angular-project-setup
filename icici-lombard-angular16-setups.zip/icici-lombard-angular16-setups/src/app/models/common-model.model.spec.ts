import { GenericPopupModel } from './common-model.model';

describe('GenericPopupModel', () => {
  it('should create an instance', () => {
    expect(new GenericPopupModel()).toBeTruthy();
  });
});
