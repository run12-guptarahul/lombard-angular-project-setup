import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class CreateCustomerResponseModel extends BaseUIResponseModel{
    CustomerId?: string;
    PfCustomerId?: string;
    emailId: string
    telephoneNo: string
    address: Address
    panCardNo: string
    passportNo: string
    aadharNo: string
    eiaNumber: any
    gstCustomerDetails: GstCustomerDetails
    landLineNum: any
    loginId: any
    iPartnerUserId: number
    pfCustomerId: string
    kycId: string;
    annualIncome: number;
    titleName: string
    gender: string
    maritalStatus: string
    name: string
    dateOfBirth: Date;
    relationShipId: number
    relationShipName: any 
    insuredOccupation: any
    requestId: string;

    protected override setData(res: any) {
        this.CustomerId = res.CustomerId;
        this.PfCustomerId = res.PfCustomerId;
        this.errorId = res.ErrorId;
        this.success = res.Success;
        this.displayMessage = res.DisplayMessage;
        this.corelationId = res.CorelationId;
        this.statusCode = res.StatusCode;
        this.technicalError = res.TechnicalError;
    }
    
    public static override withAPIData(res: any): CreateCustomerResponseModel {
        let obj = new CreateCustomerResponseModel();
        if (res != undefined && res != null) {
            obj.setData(res);
        }
        return obj;
    }
}

export class Address {
    stateName: string
    cityName: string
    cityNameStateName: string
    addressLine1: any
    addressLine2: any
    addressLine3: any
    address: string
    address2: any
    landmark: string
    stateId: number
    cityId: number
    pinCode: string
    countryId: number
  
    protected setData(res: any) {
      this.stateName = res.stateName;
      this.cityName = res.cityName;
      this.cityNameStateName = res.cityNameStateName;
      this.addressLine1 = res.addressLine1;
      this.addressLine2 = res.addressLine2;
      this.addressLine3 = res.addressLine3;
      this.address = res.address;
      this.address2 = res.address2;
      this.landmark = res.landmark;
      this.stateId = res.stateId;
      this.cityId = res.cityId;
      this.pinCode = res.pinCode;
      this.countryId = res.countryId;
    }
  
    public static withAPIData(res: any): Address {
      let obj = new Address();
      if (res != undefined && res != null) {
        obj.setData(res);
      }
      return obj;
    }
  }
  
  export class GstCustomerDetails {
    gstiN_UINNo: string = '';
    panNo: string = '';
    constitutionOfBusinessText: string = '';
    customerTypeText: string = '';
    gstRegistrationStatusText: string = '';
  
    protected setData(res: any) {
      this.gstiN_UINNo = res.gstiN_UINNo;
      this.panNo = res.panNo;
      this.constitutionOfBusinessText = res.constitutionOfBusinessText;
      this.customerTypeText = res.customerTypeText;
      this.gstRegistrationStatusText = res.gstRegistrationStatusText;
    }
  
    public static withAPIData(res: any): GstCustomerDetails {
      let obj = new GstCustomerDetails();
      if (res != undefined && res != null) {
        obj.setData(res);
      }
      return obj;
    }
  }
  
  export class CreateCustomerRequestModel {
    public RequestId: string;
    public CustomerId: string;
    public KycId: string;
    public PfCustomerId: string;
    public CustomerName: string;
    public IsCorporateCustomer: boolean;
    public EmailId: string;
    public MobileNo: string;
    public Gender: string;
    public DateOfBirth: string;
    public EIANumber: string;
    public CustomerPresentAddress: string;
    public PinCode: string;
    public CustomerPermanentAddress: string;
    public PermanentAddressPinCode: string;
    public GstNo: string;
    public PanNo: string;
    public ConstitutionOfBusiness: string;
    public GstCustomerType: string;
    public GSTRegistrationStatus: string;
    public IsPEP: boolean;
    public PEPType: string;
  }
  
  