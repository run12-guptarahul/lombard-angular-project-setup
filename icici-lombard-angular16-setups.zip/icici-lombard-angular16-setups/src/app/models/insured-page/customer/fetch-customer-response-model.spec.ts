import { FetchCustomerResponseModel } from './fetch-customer-response-model';

describe('FetchCustomerResponseModel', () => {
  it('should create an instance', () => {
    expect(new FetchCustomerResponseModel()).toBeTruthy();
  });
});