import { FetchKycCustomerResponseModel } from "./fetch-customer-kyc-response-model";


describe('FetchKycCustomerResponseModel', () => {
  it('should create an instance', () => {
    expect(new FetchKycCustomerResponseModel()).toBeTruthy();
  });
});
