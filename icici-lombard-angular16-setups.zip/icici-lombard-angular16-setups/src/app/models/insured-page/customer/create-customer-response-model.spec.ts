import { CreateCustomerResponseModel } from './create-customer-response-model';

describe('CreateCustomerResponseModel', () => {
  it('should create an instance', () => {
    expect(new CreateCustomerResponseModel()).toBeTruthy();
  });
});