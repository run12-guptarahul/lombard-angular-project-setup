import { CreateCustomerRequestModel } from './create-customer-request-model';

describe('CreateCustomerRequestModel', () => {
  it('should create an instance', () => {
    expect(new CreateCustomerRequestModel()).toBeTruthy();
  });
});