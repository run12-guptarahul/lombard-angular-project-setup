export class CreateCustomerRequestModel {
    RequestId?: string;
    CustomerId?: string;
    KycId?: string;
    PfCustomerId?: string;
    CustomerName?: string;
    IsCorporateCustomer: boolean;
    EmailId?: string;
    MobileNo?: string;
    Gender?: string;
    DateOfBirth?: string;
    EIANumber?: string;
    CustomerPresentAddress?: string;
    PinCode?: string;
    CustomerPermanentAddress?: string;
    PermanentAddressPinCode?: string;
    GstNo?: string;
    PanNo?: string;
    ConstitutionOfBusiness?: string;
    GstCustomerType?: string;
    GSTRegistrationStatus?: string;
    PEPType?: string;
}

export class GetCustomerRequestModel {
    CustomerId?: string;
}