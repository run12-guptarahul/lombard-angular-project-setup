import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class FetchKycCustomerResponseModel extends BaseUIResponseModel {
    requestId: string;
    customerId: string
    pfpustomerId: string
    customerName: string
    kycId: string
    isCorporateCustomer: Boolean  //Basis customer type
    emailId: string
    mobileNo: string
    gender: string
    isPEP: boolean
    pEPType: string
    pincode: string;
    dateOfBirth: string
    eIANumber: string
    //Present Address
    presentAddress: string
    iinCode: string
    cityState: string
    //Permanent Address
    permanentAddress: string
    permanentAddressPinCode: string
    permanentAddressCityState: string
    // GST
    gstNo: string
    panCardNo: string
    constitutionOfBusiness: string
    gstCustomerType: string
    gstRegistrationStatus: string
  
    public  static override withAPIData(res): FetchKycCustomerResponseModel {
      let obj = new FetchKycCustomerResponseModel();
      if (res != undefined && res != null) {
        obj.setData(res);
      }
      return obj;
    }

    protected override setData(res) {
      this.requestId = res.RequestId;
      this.customerId = res.CustomerId;
      this.pfpustomerId = res.PfCustomerId;
      this.customerName = res.CustomerName;
      this.isCorporateCustomer = res.IsCorporateCustomer;
      this.emailId = res.EmailId;
      this.mobileNo = res.MobileNo;
      this.gender = res.Gender;
      this.dateOfBirth = res.DateOfBirth;
      this.eIANumber = res.EIANumber;
      this.permanentAddress = res.PermanentAddress;
      this.permanentAddressPinCode = res.PermanentAddressPinCode
      this.permanentAddressCityState = res.PermanentAddressCityState
  
      this.presentAddress = res.PresentAddress;
      this.pincode = res.PinCode;
      this.cityState = res.CityState;
      this.gstNo = res.GstNo;
      this.panCardNo = res.PanNo;
      this.constitutionOfBusiness = res.ConstitutionOfBusiness;
      this.gstCustomerType = res.GstCustomerType;
      this.gstRegistrationStatus = res.GSTRegistrationStatus;
      this.kycId = res.KycId;

      super.setData(res);
    }
  }
  