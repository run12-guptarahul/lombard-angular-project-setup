export class FetchCustomerRequestModel {
    CustomerId?: string;
    PfCustomerId?: string; 
}