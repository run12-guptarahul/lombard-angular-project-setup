import { FetchCustomerRequestModel } from './fetch-customer-request-model';

describe('FetchCustomerRequestModel', () => {
  it('should create an instance', () => {
    expect(new FetchCustomerRequestModel()).toBeTruthy();
  });
});