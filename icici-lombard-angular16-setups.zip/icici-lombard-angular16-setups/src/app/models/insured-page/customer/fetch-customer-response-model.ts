import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class FetchCustomerResponseModel extends BaseUIResponseModel{
    RequestId?: string;
    CustomerId?: string;
    PfCustomerId?: string;
    CustomerName?: string;
    IsCorporateCustomer: boolean;
    EmailId?: string;
    MobileNo?: string;
    Gender?: string;
    DateOfBirth?: string;
    EIANumber?: string;
    KycId?: string;
    IsPEP?: string;
    PEPType?: string;
    PresentAddress?: string;
    PinCode?: string;
    CityState?: string;
    PermanentAddress?: string;
    PermanentAddressPinCode?: string;
    PermanentAddressCityState?: string;
    GstNo?: string;
    PanNo?: string;
    ConstitutionOfBusiness?: string;
    GstCustomerType?: string;
    GSTRegistrationStatus?: string;

    protected override setData(res: any) {
        this.RequestId = res.RequestId;
        this.CustomerId = res.CustomerId;
        this.PfCustomerId = res.PfCustomerId;
        this.CustomerName = res.CustomerName;
        this.IsCorporateCustomer = res.IsCorporateCustomer;
        this.EmailId = res.EmailId;
        this.MobileNo = res.MobileNo;
        this.Gender = res.Gender;
        this.DateOfBirth = res.DateOfBirth;
        this.EIANumber = res.EIANumber;
        this.KycId = res.KycId;
        this.IsPEP = res.IsPEP;
        this.PEPType = res.PEPType;
        this.PresentAddress = res.PresentAddress;
        this.PinCode = res.PinCode;
        this.CityState = res.CityState;
        this.PermanentAddress = res.PermanentAddress;
        this.PermanentAddressPinCode = res.PermanentAddressPinCode;
        this.PermanentAddressCityState = res.PermanentAddressCityState;
        this.GstNo = res.GstNo;
        this.PanNo = res.PanNo;
        this.ConstitutionOfBusiness = res.ConstitutionOfBusiness;
        this.GstCustomerType = res.GstCustomerType;
        this.GSTRegistrationStatus = res.GSTRegistrationStatus;
        
        this.errorId = res.ErrorId;
        this.success = res.Success;
        this.displayMessage = res.DisplayMessage;
        this.corelationId = res.CorelationId;
        this.statusCode = res.StatusCode;
        this.technicalError = res.TechnicalError;
    }
    
    public static override withAPIData(res: any): FetchCustomerResponseModel {
        let obj = new FetchCustomerResponseModel();
        if (res != undefined && res != null) {
            obj.setData(res);
        }
        return obj;
    }
}