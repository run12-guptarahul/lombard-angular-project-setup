import { PedListModel } from './ped-list-model';

describe('PedListModel', () => {
  it('should create an instance', () => {
    expect(new PedListModel()).toBeTruthy();
  });
});