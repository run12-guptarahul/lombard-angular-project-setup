import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class PedListModel extends BaseUIResponseModel {
  ped: string [];
    

  protected override setData(res: any) {
    this.ped = res.ped ? res.ped : (res.Ped) ? res.Ped : [];
    
    this.errorId = res.errorId ? res.errorId : (res.ErrorId) ? res.ErrorId : '';
    this.success = res.success ? res.success : (res.Success) ? res.Success : '';
    this.displayMessage = res.displayMessage ? res.displayMessage : (res.DisplayMessage) ? res.DisplayMessage : '';
    this.corelationId = res.corelationId ? res.corelationId : (res.CorelationId) ? res.CorelationId : '';
    this.statusCode = res.statusCode ? res.statusCode : (res.StatusCode) ? res.StatusCode : '';
    this.technicalError = res.technicalError ? res.technicalError : (res.TechnicalError) ? res.TechnicalError : '';
  }

  
  public static override withAPIData(res: any): PedListModel {
    let obj = new PedListModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  
}