import { PlanConfigurationModel } from "../plan-page/premium/plans/plan-configuration/plan-configuration-model";
import { Discounts, OptionalCovers, PlanCoverGroupPremium, PlanCoverPremium } from "../plan-page/premium/premium/premium-response-model";
import { QuoteResponseModel } from "../plan-page/quote/quote-response-model";
import { Address, GstCustomerDetails } from "./customer/create-customer-response-model";
import { FetchCustomerResponseModel } from "./customer/fetch-customer-response-model";
import { ExpressCheckoutMembers, FetchProposalResponseModel, ProposalTraveller } from "./proposal/fetch-proposal-response-model";

export class InsuredUIModel {

    proposalId: string[] = [];
    requestId: string;
    planData: PlanConfigurationModel[];
    CustomerDetails: CustomerUIModel;
    InsuredDetails: Array<InsuredDetailUIModel>;
    EmergencyDetails: EmergencyDetailsUIModel;
    covers?: PlanCoverPremium[];
    coverGroups?: PlanCoverGroupPremium[];
    OptionalCovers?: OptionalCoversUIModel[];
    ExpressCheckoutMembers? : Array<ExpressCheckoutMembersUIModel>;
    discounts: Discounts[];

    //variable to use in Insured page for auto populate
    policyStartDate : string;
    policyEndDate : string;
    gst : number;
    gstRate : number;
    basicPremium : number;
    netPremium : number;
    totalPremium: number;
    finalTotalPremium : number = 0;
    sumInsured : number = 0;
    seniorCitizenSumInsured : number = 0;
    customerId : string;
    emergencyContactName: string = "";
    emergencyContactNumber: string = "";
    kycId: string;
    isOnlySeniorPLan: boolean = false;
    isExpressCheckout: boolean = false;
    seniorCitizenPremium:  number;
    pfProposalNo?: string;
    bundledProposalId?: string;
    bundledPfProposalNo?: string;
    
    pfCustomerId: any;
    permarentAddress: string = ""
    permarentPinCode: string = "";
    permarentCityState: string = "";
    GstNo: string = "";
    EIANumber: string = "";
    IsPEP: string = "";
    revisedZone: number;
    isAbhaAgreed: boolean;
    noOfAdult: number;
    noOfKid: number;
    isMedical: boolean = false;
    isUW: boolean = false;
    creditscoreId: string;
    isCibilDiscount: boolean
    landingPagePincode: string;
    tenure: number = 0;
    planType: string;
   //variable to use in Insured page for auto populate

   public static setUIData(proposalType: number, proposal: FetchProposalResponseModel, insuredUIDetails : InsuredUIModel): InsuredUIModel {
    let obj = insuredUIDetails;
    if (proposal != undefined && proposal != null) {
      obj.CustomerDetails = this.setCustomerData();
      if(proposalType == 0) {
        obj.InsuredDetails = this.setInsuredData(proposalType, proposal.isSeniorCitizen, proposal.travellers);
        obj.covers = PlanCoverPremium.withAPIDataArray(proposal.covers);
        obj.coverGroups = PlanCoverGroupPremium.withAPIDataArray(proposal.coverGroups);
        obj.discounts = Discounts.withAPIDataArray(proposal.discounts);
        obj.OptionalCovers = this.setOptionalCovers(proposal.optionalCovers);
        obj.EmergencyDetails = this.setEmergencyData(proposal);
        obj.ExpressCheckoutMembers = this.setExpressCheckoutMembersData(proposalType, proposal.isSeniorCitizen, proposal.expressCheckoutMembers);

        obj.requestId = proposal.requestId;
        obj.customerId = proposal.customerId;
        obj.policyStartDate = proposal.policyStartDate;
        obj.policyEndDate = proposal.policyEndDate;
        obj.gst = proposal.gst;
        obj.gstRate = proposal.gstRate;
        obj.basicPremium = proposal.basicPremium;
        obj.netPremium = proposal.basicPremium;
        obj.totalPremium = proposal.totalPremium;
        obj.sumInsured = proposal.sumInsured;
        obj.isExpressCheckout = proposal.isExpressCheckout;
        obj.pfProposalNo = proposal.pfProposalNo;
        obj.bundledProposalId = proposal.bundledProposalId;
        obj.bundledPfProposalNo = proposal.bundledPfProposalNo;
        obj.emergencyContactName = proposal.emergencyContactName ? proposal.emergencyContactName : '';
        obj.emergencyContactNumber = proposal.emergencyContactNumber ? proposal.emergencyContactNumber : '';
        obj.tenure = 1;
      } else {
        obj.gst +=  proposal.gst;
        obj.basicPremium += proposal.basicPremium;
        obj.netPremium += proposal.basicPremium;
        obj.totalPremium  += proposal.totalPremium;
        obj.InsuredDetails.push.apply(obj.InsuredDetails, this.setInsuredData(proposalType, proposal.isSeniorCitizen, proposal.travellers));
        obj.InsuredDetails.push.apply(obj.ExpressCheckoutMembers, this.setExpressCheckoutMembersData(proposalType, proposal.isSeniorCitizen, proposal.expressCheckoutMembers));
        obj.InsuredDetails.push.apply(obj.discounts, Discounts.withAPIDataArray(proposal.discounts));
      }

      if(proposal.isSeniorCitizen) {
        obj.seniorCitizenSumInsured =  proposal.sumInsured;
      } else {
        obj.sumInsured = proposal.sumInsured;
      }
      obj.kycId = '';
      obj.pfCustomerId = '';
      obj.revisedZone =  0;
      obj.isAbhaAgreed =  false;
      obj.noOfAdult = 0;
      obj.noOfKid = 0;
      obj.creditscoreId = '';
      obj.isCibilDiscount = false;
      obj.landingPagePincode = '';      
      obj.planType = '';
    }
    return obj;
  }

  public static setCustomerData(customer: FetchCustomerResponseModel = null): CustomerUIModel {
    let obj = new CustomerUIModel();
    if (customer != undefined && customer != null) {
      obj.name = customer.CustomerName ? customer.CustomerName : '';
      obj.dateOfBirth = customer.DateOfBirth ? customer.DateOfBirth : '0001-01-01T00:00:00';
      obj.gender = customer.Gender ? customer.Gender : '';
      obj.mobileNo = customer.MobileNo ? customer.MobileNo : '';
      obj.emailId = customer.EmailId ? customer.EmailId : '';
      obj.address = customer.PresentAddress ? new Address() : new Address();
      obj.pinCode = customer.PinCode ? customer.PinCode : '';
      obj.cityState = customer.CityState ? customer.CityState : '';
      obj.gstCustomerDetails = customer.GstCustomerType ? new GstCustomerDetails() : new GstCustomerDetails();
      obj.isAccordianSubmit = customer ? true : false;
      obj.eiaNumber = customer.EIANumber || '';
      obj.kycId = customer.KycId || '';
      obj.annualIncome = 0;
      obj.insuredOccupation ='';
      obj.panCardNo = customer.PanNo || '';
      obj.ecsCustomerId = customer.CustomerId || '';
      obj.customerId = customer.PfCustomerId || '';
      obj.telephoneNo = customer.MobileNo || '';
      obj.requestId = customer.RequestId || '';
    }
    return obj;
  }

  public static setInsuredData(proposalType: number, isSeniorCitizen : boolean, insureds: ProposalTraveller[]): InsuredDetailUIModel[] {

    let obj = new Array<InsuredDetailUIModel>();
    let indexCount;
    insureds.forEach((item) => {
      // let age = Math.floor(
      //   (Math.abs(Date.now() - new Date(
      //     item.dateOfBirth.split("T")[0] // dob of insured
      //   ).getTime()) / (1000 * 3600 * 24) // timediff
      // )/365.25); // age

      // if (age > 70)
      //   indexCount = 3;
      // else
      //   indexCount = 2;
      
      let insured = new InsuredDetailUIModel()
      {
        insured.name = item.name;
        insured.dateOfBirth = item.dateOfBirth ? item.dateOfBirth : '';
        insured.gender = item.gender ? item.gender : 'Male';
        insured.passportNumber = item.passportNumber ? item.passportNumber : '';
        insured.relationshipWithApplicant = item.relationshipWithApplicant ?  item.relationshipWithApplicant : '';
        insured.isPed = item.isPED ? item.isPED : false;
        insured.ped = item.ped ? item.ped : '';
        insured.ageGroup = item.ageGroup ? item.ageGroup : '';
        insured.nominee = item.nomineeName ? item.nomineeName : '';
        insured.relationshipWithNominee = item.relationshipWithNominee ? item.relationshipWithNominee : '';
        insured.seniorAdultType = proposalType;
        insured.isSeniorCitizen = isSeniorCitizen;
      };
      obj.push(insured);
    })
    return obj;
  }

  public static setEmergencyData(proposal: FetchProposalResponseModel): EmergencyDetailsUIModel {
    let obj = new EmergencyDetailsUIModel();
    if (proposal != undefined && proposal != null) {
      obj.emergencyContactName = proposal.emergencyContactName ? proposal.emergencyContactName : '';
      obj.emergencyContactNumber = proposal.emergencyContactNumber ? proposal.emergencyContactNumber : '';
      
    }
    
    return obj;
  }

  public static setOptionalCovers(covers: OptionalCovers[]): OptionalCoversUIModel[] {
    let obj = new Array<OptionalCoversUIModel>();
    if (covers != undefined && covers != null && covers.length > 0) {
      covers.forEach((item) => {
        let cover = new OptionalCoversUIModel()
        {
          cover.coverCode = item.coverCode ? item.coverCode : '';
          cover.displaySequence = item.displaySequence ? item.displaySequence : 0;
          cover.premium = item.premium ? item.premium : 0;
        };
        obj.push(cover);
      }) 
    }
    return obj;
  }


  public static setExpressCheckoutMembersData(proposalType: number, isSeniorCitizen : boolean, insureds: ExpressCheckoutMembers[]): ExpressCheckoutMembersUIModel[] {

    let obj = new Array<ExpressCheckoutMembersUIModel>();
    insureds.forEach((item) => {
      let insured = new ExpressCheckoutMembersUIModel()
      {
        insured.name = item.name ? item.name[0].toUpperCase() + item.name.substring(1).toLowerCase() : '';
        insured.dateOfBirth = item.dateOfBirth ? item.dateOfBirth : '';
        insured.passportNumber = item.passportNumber ? item.passportNumber : '';
        insured.gender = item.gender ? item.gender : 'Male';
        insured.relationshipWithApplicant = item.relationshipWithApplicant ? item.relationshipWithApplicant[0].toUpperCase() + item.relationshipWithNominee.substring(1).toLowerCase() : '';
        insured.isPed = item.isPED ? item.isPED : false;
        insured.ped = item.ped  ? item.ped : '';
        insured.nominee = item.nomineeName ? item.nomineeName[0].toUpperCase() + item.nomineeName.substring(1).toLowerCase()  : '';
        insured.relationshipWithNominee = item.relationshipWithNominee ? item.relationshipWithNominee[0].toUpperCase() + item.relationshipWithNominee.substring(1).toLowerCase() : '';
      };
      obj.push(insured);
    })
    return obj;
  }
}

export class CustomerUIModel {
    name: string = "";
    dateOfBirth:string = "";
    gender: string = "";
    mobileNo: string = "";
    emailId: string = "";
    address: Address = new Address();
    pinCode: string = "";
    cityState: string = "";
    isAccordianSubmit: boolean = false;
    gstCustomerDetails: GstCustomerDetails = new GstCustomerDetails();
  
    eiaNumber: string = "";
    kycId: string = "";
    annualIncome: number = 0;
    insuredOccupation: string = "";
    panCardNo: string = "";
  
    requestId: string = "";
    ecsCustomerId: string = "";
    customerId: string = "";
    telephoneNo: string = "";
  
  
  }
  export class InsuredDetailUIModel {
    name: string = "";
    dateOfBirth: string = "";
    gender: string = "";
    passportNumber: string = "";
    relationshipWithApplicant: string = ""
    isPed: boolean;
    ped: string;
    nominee: string = "";
    relationshipWithNominee: string = "";
    ageGroup: string = "";

    isSeniorCitizen: boolean = false;
    seniorAdultType: number;
    isAccordianActive: boolean = false;
    isAccordianSubmit: boolean = false;
    dobDisabled: boolean = false;
    indexCount: number;
    insuredOccupation: string = "";
    isPreviouslyInsured: boolean = false;
    policyWaiverPeriod: number = 0;
  }
  export class EmergencyDetailsUIModel {
    emergencyContactName: string = "";
    emergencyContactNumber: string = "";
    isAccordianActive: boolean = false;
    isAccordianSubmit: boolean = false;
  }

  export class ExpressCheckoutMembersUIModel {
    name: string = "";
    dateOfBirth: string = "";
    gender: string = "";
    passportNumber: string = "";
    relationshipWithApplicant: string = ""
    isPed: boolean;
    ped: string = "";
    nominee: string = "";
    relationshipWithNominee: string = "";
    indexCount: number;
  }

  export class OptionalCoversUIModel {
    coverCode: string = "";
    displaySequence: number;
    premium : Number;
  }

  export class ailmentsCollModel {
    ageOfInsured: number = 0;
    ailmentID: number;
    ailmentName: string;
    ailmentStartDate: string;
    healthMemberID: number;
    memberAilmentID: number;
    pedCode: number;
    otherAilment: null;
    mappedAilmentId: null;
    pedIllness: null;
  
  }
  


