import { ProposalRequestModel } from './proposal-request-model';

describe('ProposalRequestModel', () => {
  it('should create an instance', () => {
    expect(new ProposalRequestModel()).toBeTruthy();
  });
});
