import { ProposalResponseModel } from './proposal-response-model';

describe('ProposalResponseModel', () => {
  it('should create an instance', () => {
    expect(new ProposalResponseModel()).toBeTruthy();
  });
});
