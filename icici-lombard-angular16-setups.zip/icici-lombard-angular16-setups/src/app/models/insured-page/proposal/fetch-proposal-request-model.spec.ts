import { FetchProposalRequestModel } from './fetch-proposal-request-model';

describe('FetchProposalRequestModel', () => {
  it('should create an instance', () => {
    expect(new FetchProposalRequestModel()).toBeTruthy();
  });
});
