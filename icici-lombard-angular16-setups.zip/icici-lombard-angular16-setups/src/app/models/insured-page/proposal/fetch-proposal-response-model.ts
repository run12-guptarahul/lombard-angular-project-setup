import { IS_PROPOSAL_OTP_AUTH } from "src/app/constant/constants";
import { BaseUIResponseModel } from "../../base/base-ui-response-model";
import { Discounts, OptionalCovers, PlanCoverGroupPremium, PlanCoverPremium } from "../../plan-page/premium/premium/premium-response-model";
import { expressCheckoutMembersAPI } from "src/app/constant/static-api-json";
import { Utility } from "src/app/constant/utility";

export class FetchProposalResponseModel extends BaseUIResponseModel {
  requestId?: string;
  customerId?: string;
  emergencyContactName?: string;
  emergencyContactNumber?: string;
  proposalId?: string;
  policyStartDate?: string;
  policyEndDate?: string;
  basicPremium: number;
  gst: number;
  gstRate: number;
  totalPremium: number;
  sumInsured: number;
  isSeniorCitizen: boolean;
  isExpressCheckout: boolean;
  pfProposalNo?: string;
  bundledProposalId?: string;
  bundledPfProposalNo?: string;
  covers?: PlanCoverPremium[];
  optionalCovers?: OptionalCovers[];
  
  coverGroups?: PlanCoverGroupPremium[];
  travellers?: ProposalTraveller[];
  expressCheckoutMembers?: ExpressCheckoutMembers[];
  discounts: Discounts[];

  protected override setData(res: any) {
    this.requestId = res.requestId ? res.requestId : (res.RequestId) ? res.RequestId : '';
    this.customerId = res.customerId ? res.customerId : (res.CustomerId) ? res.CustomerId : '';
    this.emergencyContactName = res.emergencyContactName ? res.emgrgencyContactName : (res.EmgrgencyContactName) ? res.EmgrgencyContactName : '';
    this.emergencyContactNumber = res.emergencyContactNumber ? res.emergencyContactNumber : (res.EmergencyContactNumber) ? res.EmergencyContactNumber : '';
    this.proposalId = res.proposalId ? res.proposalId : (res.ProposalId) ? res.ProposalId : '';
    this.policyStartDate = res.policyStartDate ? res.policyStartDate : (res.PolicyStartDate) ? res.PolicyStartDate : '';
    this.policyEndDate = res.policyEndDate ? res.policyEndDate : (res.PolicyEndDate) ? res.PolicyEndDate : '';
    this.basicPremium = res.basicPremium ? res.basicPremium : (res.BasicPremium) ? res.BasicPremium : '';
    this.gst = res.gst ? res.gst : (res.Gst) ? res.Gst : '';
    this.gstRate = res.gstRate ? res.gstRate : (res.GstRate) ? res.GstRate : '18';
    this.totalPremium = res.totalPremium ? res.totalPremium : (res.TotalPremium) ? res.TotalPremium : '';
    this.sumInsured = res.sumInsured ? res.sumInsured : (res.SumInsured) ? res.SumInsured : '';
    this.isSeniorCitizen = res.isSeniorCitizen ? res.isSeniorCitizen : (res.IsSeniorCitizen) ? res.IsSeniorCitizen : false;
    this.isExpressCheckout = res.isExpressCheckout ? res.isExpressCheckout : (res.IsExpressCheckout) ? res.IsExpressCheckout : false;
    this.pfProposalNo = res.pfProposalNo ? res.pfProposalNo : (res.PfProposalNo) ? res.PfProposalNo : '';
    this.bundledProposalId = res.bundledProposalId ? res.bundledProposalId : (res.BundledProposalId) ? res.BundledProposalId : '';
    this.bundledPfProposalNo = res.bundledPfProposalNo ? res.bundledPfProposalNo : (res.BundledPfProposalNo) ? res.BundledPfProposalNo : '';
    this.covers = res.covers ? res.covers : (res.Covers) ? res.Covers : '';
    this.optionalCovers = res.optionalCovers ? res.optionalCovers : (res.OptionalCovers) ? res.OptionalCovers : '';
  
    this.travellers =  ProposalTraveller.withAPIDataArray(res.Travellers) ;
    this.expressCheckoutMembers = ExpressCheckoutMembers.withAPIDataArray(res.ExpressCheckoutMembers);
    //this.expressCheckoutMembers = ExpressCheckoutMembers.withAPIDataArray(JSON.parse(JSON.stringify(expressCheckoutMembersAPI)).ExpressCheckoutMembers);
    this.coverGroups = PlanCoverGroupPremium.withAPIDataArray(res.CoverGroups);
    this.discounts = Discounts.withAPIDataArray(res.discounts ? res.discounts : (res.Discounts) ? res.Discounts : []);

    //if(this.isExpressCheckout == false)
      sessionStorage.setItem(IS_PROPOSAL_OTP_AUTH, 'true');
        
    this.errorId = res.errorId ? res.errorId : (res.ErrorId) ? res.ErrorId : '';
    this.success = res.success ? res.success : (res.Success) ? res.Success : '';
    this.displayMessage = res.displayMessage ? res.displayMessage : (res.DisplayMessage) ? res.DisplayMessage : '';
    this.corelationId = res.corelationId ? res.corelationId : (res.CorelationId) ? res.CorelationId : '';
    this.statusCode = res.statusCode ? res.statusCode : (res.StatusCode) ? res.StatusCode : '';
    this.technicalError = res.technicalError ? res.technicalError : (res.TechnicalError) ? res.TechnicalError : '';
  }

  public static override withAPIData(res: any): FetchProposalResponseModel {
    let obj = new FetchProposalResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  
}

export class ProposalTraveller extends BaseUIResponseModel {
  name?: string;
  dateOfBirth?: string;
  gender?: string;
  passportNumber?: string;
  relationshipWithApplicant?: string;
  nomineeName? : string;
  relationshipWithNominee? : string;
  isPED?: boolean;
  ped?: string;
  ageGroup?: string;
  

    protected override setData(res: any) {
        this.name = res.name ? res.name : (res.Name) ? res.Name : "";
        this.dateOfBirth = res.dateOfBirth ? res.dateOfBirth : (res.DateOfBirth) ? res.DateOfBirth : "";
        this.gender = res.gender ? res.gender : (res.Gender) ? res.Gender : "";
        this.passportNumber = res.passportNumber ? res.passportNumber : (res.PassportNumber) ? res.PassportNumber : "";
        this.relationshipWithApplicant = res.relationshipWithApplicant ? res.relationshipWithApplicant : (res.RelationshipWithApplicant) ? res.RelationshipWithApplicant : "";
        this.nomineeName = res.nomineeName ? res.nomineeName : (res.NomineeName) ? res.NomineeName : "";
        this.relationshipWithNominee = res.relationshipWithNominee ? res.relationshipWithNominee : (res.RelationshipWithNominee) ? res.RelationshipWithNominee : "";
        this.isPED = res.isPED ? res.isPED : (res.IsPED) ? res.IsPED : false;
        this.ped = res.ped ? res.ped : (res.PED) ? res.PED : "";
        this.ageGroup = res.ageGroup ? res.ageGroup : (res.AgeGroup) ? res.AgeGroup : "";
        // let InsuredAge = Utility.AgeCalculation(new Date(this.dateOfBirth));
        // if (InsuredAge >= 0 && InsuredAge <= 50)
        //   this.ageGroup = 'AG0_50';
        // else if (InsuredAge >= 51 && InsuredAge <= 60)
        //   this.ageGroup = 'AG51_60';
        // else if (InsuredAge >= 61 && InsuredAge <= 70)
        //   this.ageGroup = 'AG61_70';
        // else if (InsuredAge >= 71 && InsuredAge <= 85)
        //   this.ageGroup = 'AG71_85';
      }

    public static override withAPIData(res: any): ProposalTraveller {
        let obj = new ProposalTraveller();
        if (res != undefined && res != null) {
          obj.setData(res);
        }
        return obj;
      }

      public static withAPIDataArray(res: any): ProposalTraveller[] {
        let TravellersList: ProposalTraveller[] = [];
        let obj: ProposalTraveller;
        if (res != undefined && res != null) {
          for (let i = 0; i < res.length; i++) {
            obj = ProposalTraveller.withAPIData(res[i]);
            TravellersList.push(obj);
          }
        }
        return TravellersList.sort((a, b) => a.ageGroup.localeCompare(b.ageGroup));
       // .sort((a, b) => new Date(b.dateOfBirth).getTime() - new Date(a.dateOfBirth).getTime());
      }
}


export class ExpressCheckoutMembers extends BaseUIResponseModel {
  name?: string;
  dateOfBirth?: string;
  gender?: string;
  passportNumber?: string;
  relationshipWithApplicant?: string;
  nomineeName? : string;
  relationshipWithNominee? : string;
  isPED?: boolean;
  ped?: string;
  

    protected override setData(res: any) {
        this.name = res.name ? res.name : (res.Name) ? res.Name : '';
        this.dateOfBirth = res.dateOfBirth ? res.dateOfBirth : (res.DateOfBirth) ? res.DateOfBirth : '';
        this.gender = res.gender ? res.gender : (res.Gender) ? res.Gender : '';
        this.passportNumber = res.passportNumber ? res.passportNumber : (res.PassportNumber) ? res.PassportNumber : '';
        this.relationshipWithApplicant = res.relationshipWithApplicant ? res.relationshipWithApplicant : (res.RelationshipWithApplicant) ? res.RelationshipWithApplicant : '';
        this.nomineeName = res.nomineeName ? res.nomineeName : (res.NomineeName) ? res.NomineeName : '';
        this.relationshipWithNominee = res.relationshipWithNominee ? res.relationshipWithNominee : (res.RelationshipWithNominee) ? res.RelationshipWithNominee : '';
        this.isPED = res.isPED ? res.isPED : (res.IsPED) ? res.IsPED : false;
        this.ped = res.ped ? res.ped : (res.PED) ? res.PED : "";
      }

    public static override withAPIData(res: any): ExpressCheckoutMembers {
        let obj = new ExpressCheckoutMembers();
        if (res != undefined && res != null) {
          obj.setData(res);
        }
        return obj;
      }

      public static withAPIDataArray(res: any): ExpressCheckoutMembers[] {
        let TravellersList: ExpressCheckoutMembers[] = [];
        let obj: ExpressCheckoutMembers;
        if (res != undefined && res != null) {
          for (let i = 0; i < res.length; i++) {
            obj = ExpressCheckoutMembers.withAPIData(res[i]);
            TravellersList.push(obj);
          }
        }
        return TravellersList.sort((a, b) => new Date(b.dateOfBirth).getTime() - new Date(a.dateOfBirth).getTime());
      }
      
}
