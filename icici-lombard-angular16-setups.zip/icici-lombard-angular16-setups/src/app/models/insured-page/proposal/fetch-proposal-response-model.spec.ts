import { FetchProposalResponseModel } from './fetch-proposal-response-model';

describe('FetchProposalResponseModel', () => {
  it('should create an instance', () => {
    expect(new FetchProposalResponseModel()).toBeTruthy();
  });
});
