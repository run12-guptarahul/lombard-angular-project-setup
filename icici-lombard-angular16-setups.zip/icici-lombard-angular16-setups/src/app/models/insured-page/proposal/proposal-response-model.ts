import { BaseUIResponseModel } from "../../base/base-ui-response-model";
import { PlanCoverGroupPremium, PlanCoverPremium } from "../../plan-page/premium/premium/premium-response-model";

export class ProposalResponseModel  extends BaseUIResponseModel{
    proposalId?: string;
    pfProposalNo?: string;
    bundledProposalId?: string;
    bundledPfProposalNo?: string;
    policyStartDate?: string;
    policyEndDate?: string;
    basePremium?: number;
    gst?: number;
    totalPremium?: number;
    sumInsured?: number;
    covers?: PlanCoverPremium[];
    coverGroups?: PlanCoverGroupPremium[];
    optionalCovers?: PlanCoverPremium[];

    protected override setData(res: any) {
        this.proposalId = res.proposalId ? res.proposalId : (res.ProposalId) ? res.ProposalId : '';
        this.pfProposalNo = res.pfProposalNo ? res.pfProposalNo : (res.PfProposalNo) ? res.PfProposalNo : '';
        this.bundledProposalId = res.bundledProposalId ? res.bundledProposalId : (res.BundledProposalId) ? res.BundledProposalId : '';
        this.bundledPfProposalNo = res.bundledPfProposalNo ? res.bundledPfProposalNo : (res.BundledPfProposalNo) ? res.BundledPfProposalNo : '';
        this.policyStartDate = res.policyStartDate ? res.policyStartDate : (res.PolicyStartDate) ? res.PolicyStartDate : '';
        this.policyEndDate = res.policyEndDate ? res.policyEndDate : (res.PolicyEndDate) ? res.PolicyEndDate : '';
        this.basePremium = res.basePremium ? res.basePremium : (res.BasePremium) ? res.BasePremium : '';
        this.gst = res.gst ? res.gst : (res.Gst) ? res.Gst : '';
        this.totalPremium = res.totalPremium ? res.totalPremium : (res.TotalPremium) ? res.TotalPremium : '';
        this.sumInsured = res.sumInsured ? res.sumInsured : (res.SumInsured) ? res.SumInsured : '';
        this.covers = res.covers ? res.covers : (res.Covers) ? res.Covers : '';
        this.optionalCovers = res.optionalCovers ? res.optionalCovers : (res.OptionalCovers) ? res.OptionalCovers : '';

        this.coverGroups = PlanCoverGroupPremium.withAPIDataArray(res.CoverGroups);    
    
        this.errorId = res.errorId ? res.errorId : (res.ErrorId) ? res.ErrorId : '';
        this.success = res.success ? res.success : (res.Success) ? res.Success : '';
        this.displayMessage = res.displayMessage ? res.displayMessage : (res.DisplayMessage) ? res.DisplayMessage : '';
        this.corelationId = res.corelationId ? res.corelationId : (res.CorelationId) ? res.CorelationId : '';
        this.statusCode = res.statusCode ? res.statusCode : (res.StatusCode) ? res.StatusCode : '';
        this.technicalError = res.technicalError ? res.technicalError : (res.TechnicalError) ? res.TechnicalError : '';
      }
    
      public static override withAPIData(res: any): ProposalResponseModel {
        let obj = new ProposalResponseModel();
        if (res != undefined && res != null) {
          obj.setData(res);
        }
        return obj;
      }
    
}
