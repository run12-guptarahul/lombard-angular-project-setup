export class FetchProposalRequestModel {
    ProposalId?: string;
}
