import { Utility } from "src/app/constant/utility";
import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class ProposalRequestModel {
  RequestId?: string;
  ProposalId?: string;
  CustomerId?: string;
  KycId?: string;
  Travellers?: Traveller[];
  EmergencyContactName?: string;
  EmergencyContactNumber?: string;
}

export class Traveller extends BaseUIResponseModel {
  
  Name?: string;
  DateOfBirth?: string;
  Gender?: string;
  PassportNumber?: string;
  RelationshipWithApplicant?: string;
  NomineeName? : string;
  RelationshipWithNominee? : string;
  IsPED?: boolean;
  PED?: string;
  AbhaId?: string;
  AgeGroup?: string;

    protected override setData(res: any) {
        this.Name = res.name ? res.name : (res.Name) ? res.Name : "";
        this.DateOfBirth = res.dateOfBirth ? Utility.formatDate(res.dateOfBirth) : (res.DateOfBirth) ? Utility.formatDate(res.DateOfBirth) : "";
        this.Gender = res.gender ? res.gender : (res.Gender) ? res.Gender : "";
        this.PassportNumber = res.passportNumber ? res.passportNumber : (res.PassportNumber) ? res.PassportNumber : "";
        this.RelationshipWithApplicant = res.relationshipWithApplicant ? res.relationshipWithApplicant : (res.RelationshipWithApplicant) ? res.RelationshipWithApplicant : "";
        this.NomineeName = res.nominee ? res.nominee : (res.Nominee) ? res.Nominee : "";
        this.RelationshipWithNominee = res.relationshipWithNominee ? res.relationshipWithNominee : (res.RelationshipWithNominee) ? res.RelationshipWithNominee : "";
        this.IsPED = res.isPed ? res.isPed : (res.IsPed) ? res.IsPed : false;
        this.PED = res.ped ? res.ped : (res.Ped) ? res.Ped : "";
        this.AbhaId = "";
        this.AgeGroup = res.ageGroup ? res.ageGroup : (res.AgeGroup) ? res.AgeGroup : '';
      }

    public static override withAPIData(res: any): Traveller {
        let obj = new Traveller();
        if (res != undefined && res != null) {
          obj.setData(res);
        }
        return obj;
      }

      public static withAPIDataArray(res: any): Traveller[] {
        let TravellersList: Traveller[] = [];
        let obj: Traveller;
        if (res != undefined && res != null) {
          for (let i = 0; i < res.length; i++) {
            obj = Traveller.withAPIData(res[i]);
            TravellersList.push(obj);
          }
        }
        return TravellersList;
      }
}
