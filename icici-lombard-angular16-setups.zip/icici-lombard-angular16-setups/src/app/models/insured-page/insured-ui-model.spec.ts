import { InsuredUIModel } from './insured-ui-model';

describe('InsuredUIModel', () => {
  it('should create an instance', () => {
    expect(new InsuredUIModel()).toBeTruthy();
  });
});
