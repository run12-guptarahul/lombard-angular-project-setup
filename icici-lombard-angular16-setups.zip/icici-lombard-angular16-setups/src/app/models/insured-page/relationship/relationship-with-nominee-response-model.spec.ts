import { RelationshipWithNomineeResponseModel } from './relationship-with-nominee-response-model';

describe('RelationshipWithNomineeResponseModel', () => {
  it('should create an instance', () => {
    expect(new RelationshipWithNomineeResponseModel()).toBeTruthy();
  });
});
