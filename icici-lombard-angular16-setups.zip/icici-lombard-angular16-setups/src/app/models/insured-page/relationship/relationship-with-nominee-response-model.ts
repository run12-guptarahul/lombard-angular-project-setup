import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class RelationshipWithNomineeResponseModel  extends BaseUIResponseModel{
    relationshipWithNominee?: string[]; 

    protected override setData(res: any) {

        this.relationshipWithNominee = res.Relationships
       
        this.errorId = res.errorId ? res.errorId : (res.ErrorId) ? res.ErrorId : '';
        this.success = res.success ? res.success : (res.Success) ? res.Success : '';
        this.displayMessage = res.displayMessage ? res.displayMessage : (res.DisplayMessage) ? res.DisplayMessage : '';
        this.corelationId = res.corelationId ? res.corelationId : (res.CorelationId) ? res.CorelationId : '';
        this.statusCode = res.statusCode ? res.statusCode : (res.StatusCode) ? res.StatusCode : '';
        this.technicalError = res.technicalError ? res.technicalError : (res.TechnicalError) ? res.TechnicalError : '';
      }

    public static override withAPIData(res: any): RelationshipWithNomineeResponseModel {
        let obj = new RelationshipWithNomineeResponseModel();
        if (res != undefined && res != null) {
          obj.setData(res);
        }
        return obj;
      }
}