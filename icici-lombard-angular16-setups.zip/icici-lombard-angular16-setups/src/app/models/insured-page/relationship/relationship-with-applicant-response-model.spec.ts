import { RelationshipWithApplicantResponseModel } from './relationship-with-applicant-response-model';

describe('RelationshipWithApplicantResponseModel', () => {
  it('should create an instance', () => {
    expect(new RelationshipWithApplicantResponseModel()).toBeTruthy();
  });
});
