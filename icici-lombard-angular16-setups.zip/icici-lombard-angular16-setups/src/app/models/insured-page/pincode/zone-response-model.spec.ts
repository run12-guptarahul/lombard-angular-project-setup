import { ZoneResponseModel } from './zone-response-model';

describe('ZoneResponseModel', () => {
  it('should create an instance', () => {
    expect(new ZoneResponseModel()).toBeTruthy();
  });
});
