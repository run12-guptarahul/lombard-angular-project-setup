export class PincodeResponseModel {
    cityDistrictId: string = "";
    cityDistrictName: string = "";
    countryId: number = 0;
  
    protected setData(res: any) {
      this.cityDistrictId = res.cityDistrictId;
      this.cityDistrictName = res.cityDistrictName;
      this.countryId = res.countryId;
    }
  
    public static withAPIData(res: any): PincodeResponseModel {
      let obj = new PincodeResponseModel();
      if (res != undefined && res != null) {
        obj.setData(res);
      }
      return obj;
    }
  
  }
  