import { BaseUIResponseModel } from "src/app/models/base/base-ui-response-model";
import { PRODUCT_CODE } from "src/app/constant/constants";

export class ZoneRequestModel {
  productCode: string = PRODUCT_CODE.toString();
  pinCode: string;
  state: string;
  city: string;
}

export class ZoneResponseModel extends BaseUIResponseModel {
  zoneId: string;

  protected override setData(res: any) {
    this.zoneId = res.zoneId;
    super.setData(res);
  }

  public static override withAPIData(res: any): ZoneResponseModel {
    let obj = new ZoneResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
}
