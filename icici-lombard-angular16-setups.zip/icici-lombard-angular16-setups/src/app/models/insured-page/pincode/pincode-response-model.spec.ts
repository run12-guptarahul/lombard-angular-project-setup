import { PincodeResponseModel } from './pincode-response-model';

describe('PincodeResponseModel', () => {
  it('should create an instance', () => {
    expect(new PincodeResponseModel()).toBeTruthy();
  });
});
