export class PaymentTransactionRequestModel {
    ProposalId: string[] = [];
    PANNo: string = "";
    CSRPartner: string = "";
    DonationAmount: string = "";
  }
  
  export class PaymentTransactionRequestUIModel {
    public Proposal: PaymentTransactionProposal[] = [];
    public PaymentLinkId: string;
    public HostUrl: string;
  }
  
  export class PaymentTransactionProposal {
    public ProposalId: string;
    public PolicyId: number;
    public PfProposalNo: string;
    public DonationAmount: number;
    public CSRPartner: string;
    public QuoteId: string;
  }
  