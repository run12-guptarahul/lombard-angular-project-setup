import { BaseUIResponseModel } from "../base/base-ui-response-model";


export class PaymentTransactionResponseModel extends BaseUIResponseModel {
  PaymentTransactionId: string = "";
  RedirectUrl: string = "";
  clientIpAddress: string = ""

  public static override withAPIData(res): PaymentTransactionResponseModel {
    let obj = new PaymentTransactionResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }

  protected override setData(res) {
    this.PaymentTransactionId = res.paymentTransactionId;
    this.RedirectUrl = res.redirectUrl;

    this.success = res.success;
    this.errorMessage = res.errorMessage;
    this.corelationId = res.corelationId;
    this.technicalErrorMessage = res.technicalErrorMessage;
    this.status = res.status;
    this.clientIpAddress = res.clientIpAddress;
  }
}

export class PaymentTransactionResponseUIModel {
  TransactionId: string = "";
  RedirectUrl: string = "";
  public Success: boolean;
  public StatusCode: number;
  public DisplayMessage: string;
  public CorelationId: string;
  public TechnicalError: string;

  public static withAPIData(res): PaymentTransactionResponseUIModel {
    let obj = new PaymentTransactionResponseUIModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }

  protected setData(res) {
    this.TransactionId = res.TransactionId;
    this.RedirectUrl = res.redirectUrl;

    this.Success = res.Success;
    this.DisplayMessage = res.DisplayMessage;
    this.CorelationId = res.corelationId;
    this.TechnicalError = res.TechnicalError;
    this.StatusCode = res.StatusCode;
    //this.ClientIpAddress = res.clientIpAddress;
  }
}
