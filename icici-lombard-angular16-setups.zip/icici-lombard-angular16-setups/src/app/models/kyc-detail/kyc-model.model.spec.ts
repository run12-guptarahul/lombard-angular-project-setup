import { KycModel } from './kyc-model.model';

describe('KycModel', () => {
  it('should create an instance', () => {
    expect(new KycModel()).toBeTruthy();
  });
});
