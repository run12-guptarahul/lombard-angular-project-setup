export class KycModel {
    isAadhaarOTP: boolean;
    kycId: string;
    emailID: string;
    mobileNumber: string;
    gender: string;
    dateOfBirth: string;
    customerName: string;
    permanentAddress: address
    alternateAddress: address;
    requestId: string;
    errorId: number;
    success: boolean;
    statusCode: number;
    technicalError: any;
    displayMessage: any;
    corelationId: string;
    certificationType: string;
    panNumber: string;

    public static withAPIData(res:any): KycModel {
      let obj = new KycModel();
      if (res != undefined && res != null) {
        obj.setData(res);
      }
  
      return obj;
    }
  
    protected setData(response:any){
      this.customerName =  response.customerName;
      this.alternateAddress = address.withAPIData(response.AlternateAddress);
      this.certificationType = response.CertificationType
      this.corelationId = response.CorelationId;
      this.customerName = response.CustomerName;
      this.dateOfBirth = response.DateOfBirth;
      this.displayMessage = response.DisplayMessage;
      this.emailID = response.EmailID;
      this.errorId = response.ErrorId;
      this.gender = response.Gender;
      this.isAadhaarOTP = response.IsAadhaarOTP;
      this.kycId = response.KycId;
      this.mobileNumber = response.MobileNumber
      this.permanentAddress = address.withAPIData(response.PermanentAddress);
      this.requestId = response.RequestId;
      this.panNumber = (response.PanNumber) ? response.PanNumber : '';
      this.statusCode = response.StatusCode;
      this.success = response.Success;
      this.technicalError = response.TechnicalError;
    }
  
}
  
export class address {
    address: string;
    pinCode: string;
    cityState: string;

    public static withAPIData(res:any): address {
    let obj = new address();
    if (res != undefined && res != null) {
        obj.setData(res);
    }
    return obj;
    }

    protected setData(response:any){
    this.address = response.Address;
    this.pinCode = response.PinCode;
    this.cityState = response.CityState;
    
    }
}
  