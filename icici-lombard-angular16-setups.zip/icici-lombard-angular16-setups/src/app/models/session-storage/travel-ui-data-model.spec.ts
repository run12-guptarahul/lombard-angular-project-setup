import { TravelUIDataModel } from './travel-ui-data-model';

describe('TravelUIDataModel', () => {
  it('should create an instance', () => {
    expect(new TravelUIDataModel()).toBeTruthy();
  });
});
