import { Traveller } from "../plan-page/contact-drop/contact-drop-lead-request-model"

export class TravelUIDataModel {
  emailId: string;
  mobileNo: string;
  isNonImmigrantVisa: boolean;
  landingURL: string;
  visitingCountry: any = [];
  geography: string;
  travellerType: any = [];
  tripType: string;
  tripStartDate: string;
  tripEndDate: string;
  hasSenior: boolean;
  tripDuration: number;
  travellers: Traveller[];


  protected setData(response: any) {
    let res = response;
    this.emailId = res.quoteEmailId ? res.quoteEmailId : (res.QuoteEmailId ? res.QuoteEmailId : "");
    this.mobileNo = res.quoteMobileNo ? res.quoteMobileNo : (res.QuoteMobileNo ? res.QuoteMobileNo : "");
    this.isNonImmigrantVisa = res.IsImmigrantVisa ? res.IsImmigrantVisa : (res.IsImmigrantVisa ? res.IsImmigrantVisa : false);
    this.landingURL = res.landingURL ? res.landingURL : (res.LandingURL ? res.LandingURL : "");
    this.visitingCountry = res.countryNameList ? res.countryNameList : (res.CountryNameList ? res.CountryNameList : "");
    this.geography = res.geography ? res.geography : (res.GeoScopAsia ? res.GeoScopAsia : "");
    this.tripType = res.tripType ? res.tripType : (res.TripType ? res.TripType : "");
    this.tripStartDate = res.leavingIndia ? res.leavingIndia : (res.LeavingIndia ? res.LeavingIndia : "");
    this.tripEndDate = res.returnIndia ? res.returnIndia : (res.ReturnIndia ? res.ReturnIndia : "");
    this.hasSenior = res.hasSenior ? res.hasSenior : (res.HasSenior ? res.HasSenior : "");
    this.tripDuration = TravelUIDataModel.calculateTravelDuration(this.tripStartDate, this.tripEndDate);
    this.travellers = res.travellers ? Traveller.withAPIDataArray(res.travellers) : (res.Travellers ? Traveller.withAPIDataArray(res.Travellers) : []);
    this.travellerType = res.TravellerType ? res.TravellerType : 'Adult';
  }
  protected setData1(res: any) {
    this.emailId = res.quoteEmailId ? res.quoteEmailId : (res.emailId ? res.emailId : "");
    this.mobileNo = res.quoteMobileNo ? res.quoteMobileNo : (res.mobileNo ? res.mobileNo : "");
    this.isNonImmigrantVisa = res.IsImmigrantVisa ? res.IsImmigrantVisa : (res.isNonImmigrantVisa ? res.isNonImmigrantVisa : false);
    this.landingURL = res.landingURL ? res.landingURL : (res.LandingURL ? res.LandingURL : "");
    this.visitingCountry = res.countryNameList ? res.countryNameList : (res.visitingCountry ? res.visitingCountry : "");
    this.geography = res.geography ? res.geography : (res.geography ? res.geography : "");
    this.tripType = res.tripType ? res.tripType : (res.tripType ? res.tripType : "");
    this.tripStartDate = res.leavingIndia ? res.leavingIndia : (res.tripStartDate ? res.tripStartDate : "");
    this.tripEndDate = res.r ? res.returnIndia : (res.tripEndDate ? res.tripEndDate : "");
    this.hasSenior = res.hasSenior ? res.hasSenior : (res.HasSenior ? res.asSenior : "");
    this.tripDuration = TravelUIDataModel.calculateTravelDuration(this.tripStartDate, this.tripEndDate);
    this.travellers = res.travellers ? res.travellers : (res.travellers ? res.travellers : "");
    this.travellerType = res.travellerType ? res.travellerType : 'Adult';
  }


  public static withAPIData(response: any, quote?: string): TravelUIDataModel {
    let obj = new TravelUIDataModel();
    if (response != undefined && response != null) {
      if (quote == undefined) {
        obj.setData(response);
      } else {
        obj.setData1(response);
      }

    }
    return obj;
  }


  public static createSessionData(res): TravelUIDataModel[] {
    let TravelUIData: TravelUIDataModel[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: TravelUIDataModel;
        obj = TravelUIDataModel.withAPIData(res[i]);
        TravelUIData.push(obj);
      }
    }
    return TravelUIData;
  }
  public static createSessionData1(res): TravelUIDataModel[] {
    let TravelUIData: TravelUIDataModel[] = [];
    if (res != undefined && res != null) {
      let obj: TravelUIDataModel;
      obj = TravelUIDataModel.withAPIData(res, "quote");
      TravelUIData.push(obj);
    }
    return TravelUIData;
  }

  public static calculateTravelDuration(startDate: string, endDate: string): number {
    const start = new Date(startDate);
    const end = new Date(endDate);

    // Calculate the difference in time (in milliseconds)
    const timeDiff = end.getTime() - start.getTime();

    // Convert time difference from milliseconds to days
    const travelDuration = Math.ceil(timeDiff / (1000 * 3600 * 24));

    return travelDuration;
  }



}
