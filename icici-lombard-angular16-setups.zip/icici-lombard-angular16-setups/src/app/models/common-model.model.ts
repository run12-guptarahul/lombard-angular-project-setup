import { HttpErrorResponse } from "@angular/common/http";
import { PlanMasterCover } from "./plan-page/premium/plans/plan-master-cover/plan-master-cover";

export class GenericPopupModel {
	public errorMessage: string;
	public isRedirection: boolean;
	public redirectURL: string;
	public errorResponse: HttpErrorResponse;
	public showPopup: boolean;
}

export class BenefitPopupModel {
	public cover:PlanMasterCover[];
	public showPopup: boolean;
}

export class AddonKnowMorePopupModel {
	public cover:PlanMasterCover[];
	public showPopup: boolean;
	public coverIndex:number;
	public isSelected:boolean;
}

export class ComparePlanPopupModel {
  public cover: PlanMasterCover[];
  public showPopup: boolean;
}

export class AttentionPopupModel {
	public heading: string;
	public info1: string;
	public info2: string;
	public isShowPopup: boolean;
	public btn1: boolean;
	public btn2: boolean;
}





