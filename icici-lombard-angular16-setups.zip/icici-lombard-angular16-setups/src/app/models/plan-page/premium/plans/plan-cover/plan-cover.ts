export class PlanCover {
  coverCode: string;
  displaySequence: number;
  
  protected setData(res: any) {
    this.coverCode = res.coverCode;
    this.displaySequence = res.displaySequence;
  }
  public static withAPIData(res: any): PlanCover {
    let obj = new PlanCover();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  public static withAPIDataArray(res): PlanCover[] {
    let planCoverList: PlanCover[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: PlanCover;
        obj = PlanCover.withAPIData(res[i]);
        planCoverList.push(obj);
      }
    }
    return planCoverList;
  }
  }

 