import { PlanCoverGroup } from './plan-cover-group';

describe('PlanCoverGroup', () => {
  it('should create an instance', () => {
    expect(new PlanCoverGroup()).toBeTruthy();
  });
});
