import { BaseUIResponseModel } from "src/app/models/base/base-ui-response-model";
import { PlanConfigurationModel } from "../plan-configuration/plan-configuration-model";


export class PlanPackageResponseModel extends BaseUIResponseModel {
    plans?: PlanConfigurationModel[];
    isExpressCheckout: boolean;
    geography:string;

    protected override setData(res: any) {
        this.plans = PlanConfigurationModel.withAPIDataArray(res.Plans); 
      this.isExpressCheckout = res.isExpressCheckout ? res.isExpressCheckout : res.IsExpressCheckout;
        this.geography = res.geography ? res.geography:res.Geography;
        super.setData(res);
      }
    
      public static override withAPIData(res: any): PlanPackageResponseModel {
        let obj = new PlanPackageResponseModel();
        if (res != undefined && res != null) {
          obj.setData(res);
        }
        return obj;
      }

}


