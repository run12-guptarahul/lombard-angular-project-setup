import { PlanCover } from "../plan-cover/plan-cover";
import { PlanMasterCover } from "../plan-master-cover/plan-master-cover";

export class PlanCoverGroup {
  coverGroupCode: string = "";
  displayName: string = "";
  description: string = "";
  proTipText: string = "";
  heroFeatureImagePath: string = "";
  heroFeatureMobileImagePath: string = ""
  premium:number = 0;
  isOpted: boolean;
  covers?: PlanMasterCover[];
 

  public setData(res: any) {
    this.coverGroupCode = res.coverGroupCode ? res.coverGroupCode :(res.CoverGroupCode ? res.CoverGroupCode:"");
    this.displayName = res.displayName ? res.displayName: (res.DisplayName ? res.DisplayName:"");
    this.description = res.description ? res.description:(res.Description) ? res.Description:"";
    this.proTipText = res.proTipText ? res.proTipText : (res.ProTipText) ? res.ProTipText : "";
    this.heroFeatureImagePath = res.heroFeatureImagePath ? res.heroFeatureImagePath : (res.HeroFeatureImagePath) ? res.HeroFeatureImagePath : '';
    this.heroFeatureMobileImagePath = res.heroFeatureMobileImagePath ? res.heroFeatureMobileImagePath : (res.HeroFeatureMobileImagePath) ? res.HeroFeatureMobileImagePath : '';
    this.premium = res.premium ? res.premium : (res.Premium)? res.Premium : 0;
    this.isOpted = res.isOpted ? res.isOpted : (res.IsOpted) ? res.IsOpted : false;
    this.covers = PlanMasterCover.withAPIDataArray(res.covers ? res.covers : res.Covers);
  }


  public static withAPIData(res: any): PlanCoverGroup {
    let obj = new PlanCoverGroup();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  public static withAPIDataArray(res): PlanCoverGroup[] {
    let planCoverGroupList: PlanCoverGroup[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: PlanCoverGroup;
        obj = PlanCoverGroup.withAPIData(res[i]);
        planCoverGroupList.push(obj);
      }
    }
    return planCoverGroupList;
  }

  }
