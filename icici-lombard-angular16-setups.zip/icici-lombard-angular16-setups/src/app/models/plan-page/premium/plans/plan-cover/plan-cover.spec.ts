import { PlanCover } from './plan-cover';

describe('PlanCover', () => {
  it('should create an instance', () => {
    expect(new PlanCover()).toBeTruthy();
  });
});
