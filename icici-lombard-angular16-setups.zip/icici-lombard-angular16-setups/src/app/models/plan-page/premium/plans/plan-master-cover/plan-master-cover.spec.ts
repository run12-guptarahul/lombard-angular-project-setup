import { PlanCoverMaster } from "./plan-cover-master";

describe('PlanExtensionCover', () => {
  it('should create an instance', () => {
    expect(new PlanCoverMaster()).toBeTruthy();
  });
});
