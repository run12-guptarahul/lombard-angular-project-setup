import { PlanPackageResponseModel } from './plan-package-response-model';

describe('PlanPackageResponseModel', () => {
  it('should create an instance', () => {
    expect(new PlanPackageResponseModel()).toBeTruthy();
  });
});
