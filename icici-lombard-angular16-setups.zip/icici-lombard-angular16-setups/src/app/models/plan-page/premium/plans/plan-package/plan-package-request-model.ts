import { Traveller } from "../../../contact-drop/contact-drop-lead-request-model";

export class PlanPackageRequestModel {
  tripType: string;
  geography: string;
  visitingCountry: string[];
  tripStartDate: string;
  tripEndDate: string;
  isNonImmigrantVisa: boolean;
  travellers: any[];
  mobileNo: string;
  requestId: string;
}

