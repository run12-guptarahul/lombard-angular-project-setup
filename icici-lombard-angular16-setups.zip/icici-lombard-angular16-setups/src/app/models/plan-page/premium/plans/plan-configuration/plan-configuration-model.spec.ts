import { PlanConfigurationModel } from './plan-configuration-model';

describe('PlanConfigurationModel', () => {
  it('should create an instance', () => {
    expect(new PlanConfigurationModel()).toBeTruthy();
  });
});
