import { Discounts, PlanCoverPremium } from "../../premium/premium-response-model";
import { PlanCoverGroup } from "../plan-cover-group/plan-cover-group";
import { PlanCover } from "../plan-cover/plan-cover";
import { PlanMasterCover } from "../plan-master-cover/plan-master-cover";

export class PlanConfigurationModel {
  planCode?: string;
  displayName?: string;
  isRecommended: boolean;
  isDefault: boolean;
  displaySequence: number;
  sumInsured?: number[];
  defaultSumInsured: number;
  bottomTipText:string
  covers?: PlanMasterCover[];
  coverGroups?: PlanCoverGroup[];
  description: string;
  isSeniorCitizen: boolean;

  // below variable declare for handling for calculate prem ans Quote
  isSelected:boolean = false;
  premium:number = 0;
  selectedAddonList:any[] = [];
  isCalculatePremium: boolean = false;
  proposalId: string = "";
  basicPremium: number = 0;
  gst: number = 0;
  gstRate: number = 0;
  discounts: Discounts[];
  totalDiscount: number;
  activeSI: number;

  

  public setData(res: any) {
    this.planCode = res.planCode ? res.planCode : res.PlanCode;
    this.displayName = res.displayName ? res.displayName : res.DisplayName;
    this.isRecommended = res.isRecommended ? res.isRecommended : (res.IsRecommended) ? res.IsRecommended :false;
    this.isDefault = res.isDefault ? res.isDefault : (res.IsDefault) ? res.IsDefault: false;
    this.displaySequence = res.displaySequence ? res.displaySequence :res.DisplaySequence;
    this.sumInsured = res.sumInsured ? res.sumInsured: res.SumInsured;
    this.defaultSumInsured = res.defaultSumInsured ? res.defaultSumInsured : (res.DefaultSumInsured) ? res.DefaultSumInsured :0;
    this.bottomTipText = res.bottomTipText ? res.bottomTipText:res.BottomTipText;
    this.covers = PlanMasterCover.withAPIDataArray(res.covers ? res.covers:res.Covers);
    this.coverGroups = PlanCoverGroup.withAPIDataArray(res.coverGroups ? res.coverGroups:res.CoverGroups);
    this.description = res.description ? res.description : res.Description;

    this.isSelected = (res.isSelected) ? res.isSelected : false;
    this.basicPremium = res.basicPremium ? res.basicPremium : 0;
    this.premium = res.premium ? res.premium:0;
    this.isSeniorCitizen = res.isSeniorCitizen ? res.isSeniorCitizen : (res.IsSeniorCitizen) ? res.IsSeniorCitizen : false;
    this.isCalculatePremium = res.isCalculatePremium ? res.isCalculatePremium : (res.IsCalculatePremium)? res.IsCalculatePremium:false
  }


  public static withAPIData(res: any): PlanConfigurationModel {
    let obj = new PlanConfigurationModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
     public static withAPIDataArray(res): PlanConfigurationModel[] {
        let PlanConfigurationList: PlanConfigurationModel[] = [];
        if (res != undefined && res != null && res.length > 0) {
          for (let i = 0; i < res.length; i++) {
            let obj: PlanConfigurationModel;
            obj = PlanConfigurationModel.withAPIData(res[i]);
            PlanConfigurationList.push(obj);
          }
        }
        return PlanConfigurationList;
      }

    
      
}





