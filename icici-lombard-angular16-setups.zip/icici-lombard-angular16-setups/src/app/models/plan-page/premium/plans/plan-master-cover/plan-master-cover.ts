import { BaseUIResponseModel } from "src/app/models/base/base-ui-response-model";

export class PlanMasterCover {
  coverCode?: string | null;
  coverShortName?: string | null;
  coverSection?: string | null;
  coverType?: string | null;
  coverBenefit?: string | null;
  sumInsured: number = 0;
  displaySequence: number;
  coverName: string;
  protected setData(res: any) {
    this.coverCode = res.coverCode ? res.coverCode : res.CoverCode;
    this.coverShortName = res.coverShortName ? res.coverShortName :res.CoverShortName;
    this.coverSection = res.coverSection ? res.coverSection :res.CoverSection;
    this.coverType = res.coverType ? res.coverType:res.CoverType;
    this.coverBenefit = res.coverBenefit ? res.coverBenefit : res.CoverBenefit;
    this.sumInsured = res.sumInsured ? res.sumInsured : (res.SumInsured) ? res.SumInsured : 0;
    this.displaySequence = res.displaySequence ? res.displaySequence : (res.DisplaySequence) ? res.DisplaySequence : 0;
    this.coverName = res.coverName ? res.coverName : (res.CoverName) ? res.CoverName : 'testing';
  }

  public static withAPIData(res: any): PlanMasterCover {
    let obj = new PlanMasterCover();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  public static withAPIDataArray(res): PlanMasterCover[] {
    let planMasterCoverList: PlanMasterCover[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: PlanMasterCover;
        obj = PlanMasterCover.withAPIData(res[i]);
        planMasterCoverList.push(obj);
      }
    }
    return planMasterCoverList;
  }
  }
