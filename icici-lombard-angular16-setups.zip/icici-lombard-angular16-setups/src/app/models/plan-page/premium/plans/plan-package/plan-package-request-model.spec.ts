import { PlanPackageRequestModel } from './plan-package-request-model';

describe('PlanPackageRequestModel', () => {
  it('should create an instance', () => {
    expect(new PlanPackageRequestModel()).toBeTruthy();
  });
});
