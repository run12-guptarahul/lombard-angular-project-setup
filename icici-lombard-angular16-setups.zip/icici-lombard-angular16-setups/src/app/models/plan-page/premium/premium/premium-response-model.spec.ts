import { PremiumResponseModel } from './premium-response-model';

describe('PremiumResponseModel', () => {
  it('should create an instance', () => {
    expect(new PremiumResponseModel()).toBeTruthy();
  });
});
