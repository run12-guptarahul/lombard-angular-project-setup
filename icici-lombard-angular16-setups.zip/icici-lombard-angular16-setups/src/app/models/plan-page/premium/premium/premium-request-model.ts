import { Traveller } from "../../contact-drop/contact-drop-lead-request-model";
import { PlanCoverGroup } from "../plans/plan-cover-group/plan-cover-group";
import { PlanCoverGroupPremium } from "./premium-response-model";

export class PremiumRequestModel {
  tripType?: string;
  geography?: string;
  visitingCountry?: string[];
  tripStartDate?: string;
  tripEndDate?: string;
  isNonImmigrantVisa: boolean;
  travellers?: any[]//Traveller[];
  proposalId?: string;
  isCalculatePremium: boolean;
  sumInsured: number;
  mobileNo?: string;
  emailId?: string;
  planCode?: string;
  //optionalCovers?: string[];
  coverGroup?: string[];
  requestId: string;
  isDefaultQuote: boolean;
  isExpressCheckout: boolean;
}

