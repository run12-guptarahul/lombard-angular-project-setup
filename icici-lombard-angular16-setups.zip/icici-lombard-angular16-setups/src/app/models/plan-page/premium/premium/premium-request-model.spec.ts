import { PremiumRequestModel } from './premium-request-model';

describe('PremiumRequestModel', () => {
  it('should create an instance', () => {
    expect(new PremiumRequestModel()).toBeTruthy();
  });
});
