import { BaseUIResponseModel } from "src/app/models/base/base-ui-response-model";
import { PlanCover } from "../plans/plan-cover/plan-cover";
import { PlanCoverGroup } from "../plans/plan-cover-group/plan-cover-group";
import { Traveller } from "../../contact-drop/contact-drop-lead-request-model";

export class PremiumResponseModel extends BaseUIResponseModel {
  proposalId?: string;
  planCode: string;
  basicPremium: number;
  gst: number;
  gstRate: number;
  totalPremium: number;
  sumInsured: number;
  covers?: PlanCoverPremium[];
  coverGroups?: PlanCoverPremium[];
  discounts: Discounts[]
  travellers: Traveller[];
  tripStartDate: string
  tripEndDate: string;
  tripType: string;
  visitingCountry: string[];
  requestId: string;
  planName: string;
  mobileNo: string;
  emailId: string;
  geography: string;
  isNonImmigrantVisa: string;
  isSeniorCitizen: boolean
  isExpressCheckout: boolean;


  protected override setData(res: any) {
    this.proposalId = res.proposalId ? res.proposalId : (res.ProposalId) ? res.ProposalId : "";
    this.planCode = res.planCode ? res.planCode : (res.PlanCode) ? res.PlanCode : "";
    this.basicPremium = res.basicPremium ? res.basicPremium : (res.BasicPremium) ? res.BasicPremium : "";
    this.gst = res.gst ? res.gst : (res.Gst) ? res.Gst : 0;
    this.gstRate = res.gstRate ? res.gstRate : (res.GstRate) ? res.GstRate : 0;
    this.totalPremium = res.totalPremium ? res.totalPremium : (res.TotalPremium) ? res.TotalPremium : 0;
    this.sumInsured = res.sumInsured ? res.sumInsured : (res.SumInsured) ? res.SumInsured : 0;
    this.covers = res.covers ? res.covers : (res.Covers) ? res.Covers : [];
    this.coverGroups = PlanCoverPremium.withAPIDataArray(res.coverGroups ? res.coverGroups : (res.CoverGroups) ? res.CoverGroups : []);
    this.discounts = Discounts.withAPIDataArray(res.discounts ? res.discounts : (res.Discounts) ? res.Discounts : []);

    this.travellers = res.travellers ? res.travellers : (res.Travellers ? res.Travellers : "");
    this.tripStartDate = res.tripStartDate ? res.tripStartDate : (res.TripStartDate ? res.TripStartDate : "");
    this.tripEndDate = res.tripEndDate ? res.tripEndDate : (res.TripEndDate ? res.TripEndDate : "");
    this.tripType = res.tripType ? res.tripType : (res.TripType ? res.TripType : "");
    this.visitingCountry = res.visitingCountry ? res.visitingCountry : (res.VisitingCountry ? res.VisitingCountry : "");
    this.requestId = res.requestId ? res.requestId : (res.RequestId ? res.RequestId : "");
    this.planName = res.planName ? res.planName : (res.PlanName ? res.PlanName : "");
    this.mobileNo = res.mobileNo ? res.mobileNo : (res.MobileNo ? res.MobileNo : "");
    this.emailId = res.emailId ? res.emailId : (res.EmailId ? res.EmailId : "");
    this.geography = res.geography ? res.geography : (res.Geography ? res.Geography : "");
    this.isNonImmigrantVisa = res.isNonImmigrantVisa ? res.isNonImmigrantVisa : (res.IsNonImmigrantVisa ? res.IsNonImmigrantVisa : "");
    this.isSeniorCitizen = res.isSeniorCitizen ? res.iksSeniorCitizen : (res.IsSeniorCitizen ? res.IsSeniorCitizen : false);
    this.isExpressCheckout = res.isExpressCheckout ? res.isExpressCheckout : (res.IsExpressCheckout) ? res.IsExpressCheckout : false;

    super.setData(res);
  }

  public static override withAPIData(res: any): PremiumResponseModel {
    let obj = new PremiumResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }

}
export class PlanCoverPremium {
  coverGroupCode: string;
  displayName: string;
  description: number;
  premium: number;
  isOpted: boolean;

  public setData(res: any) {
    this.coverGroupCode = res.coverGroupCode ? res.coverGroupCode : res.CoverGroupCode;
    this.description = res.description ? res.description : res.Description;
    this.premium = res.premium ? res.premium : res.Premium;
    this.isOpted = res.isOpted ? res.isOpted : (res.IsOpted) ? res.IsOpted : false;
    this.displayName = res.displayName ? res.displayName : (res.DisplayName) ? res.DisplayName : '';
  }

  public static withAPIData(res: any): PlanCoverPremium {
    let obj = new PlanCoverPremium();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  public static withAPIDataArray(res): PlanCoverPremium[] {
    let planCoverGroupList: PlanCoverPremium[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: PlanCoverPremium;
        obj = PlanCoverPremium.withAPIData(res[i]);
        planCoverGroupList.push(obj);
      }
    }
    return planCoverGroupList;
  }
}

export class OptionalCovers {
  coverCode: string = "";
  displaySequence: number;
  premium : Number;

  public setData(res: any) {
    this.coverCode = res.coverCode ? res.coverCode : res.CoverCode;
    this.displaySequence = res.displaySequence ? res.displaySequence : res.DisplaySequence;
    this.premium = res.premium ? res.premium : res.Premium;

  }

  public static withAPIData(res: any): OptionalCovers {
    let obj = new OptionalCovers();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  public static withAPIDataArray(res): OptionalCovers[] {
    let optionalCoversList: OptionalCovers[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: OptionalCovers;
        obj = OptionalCovers.withAPIData(res[i]);
        optionalCoversList.push(obj);
      }
    }
    return optionalCoversList;
  }
}

export class PlanCoverGroupPremium  extends BaseUIResponseModel {
  coverGroupCode?: string;
  displayName?: string;
  description: string;
  proTipText: string;
  HeroFeatureImagePath: string;
  premium: number;
  isOpted: boolean

  protected override setData(res: any) {
    this.coverGroupCode = res.coverGroupCode ? res.coverGroupCode : (res.CoverGroupCode) ? res.CoverGroupCode : '';
    this.description = res.description ? res.description : (res.Description) ? res.Description : '';
    this.displayName = res.displayName ? res.displayName : (res.DisplayName) ? res.DisplayName : '';
    this.premium = res.premium ? res.premium : (res.Premium) ? res.Premium : '';
    this.isOpted = res.isOpted ? res.isOpted : (res.IsOpted) ? res.IsOpted : false;
  }

public static override withAPIData(res: any): PlanCoverGroupPremium {
    let obj = new PlanCoverGroupPremium();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }

  public static withAPIDataArray(res: any): PlanCoverGroupPremium[] {
    let TravellersList: PlanCoverGroupPremium[] = [];
    let obj: PlanCoverGroupPremium;
    if (res != undefined && res != null) {
      for (let i = 0; i < res.length; i++) {
        obj = PlanCoverGroupPremium.withAPIData(res[i]);
        TravellersList.push(obj);
      }
    }
    return TravellersList;
  }


}
export class Discounts {
  discountName: string;
  amount: number;
  rate: number;

  public setData(res: any) {
    this.discountName = res.discountName ? res.discountName : (res.DiscountName) ? res.DiscountName : '';
    this.amount = res.amount ? res.amount : (res.Amount) ? res.Amount : 0;
    this.rate = res.rate ? res.rate : (res.Rate) ? res.Rate : 0;
  }

  public static withAPIData(res: any): Discounts {
    let obj = new Discounts();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }

  public static withAPIDataArray(res: any): Discounts[] {
    let discountList: Discounts[] = [];
    let obj: Discounts;
    if (res != undefined && res != null) {
      for (let i = 0; i < res.length; i++) {
        obj = Discounts.withAPIData(res[i]);
        discountList.push(obj);
      }
    }
    return discountList;
  }
}

