import { Utility } from "../../../constant/utility"

export class ContactDropRequestModel {
  TripType: string
  Geography: string
  VisitingCountry: string[]
  TripStartDate: string
  TripEndDate: string
  IsNonImmigrantVisa: boolean
  Travellers: Traveller[]
  MobileNo: string
  EmailId: string
}
export class Traveller {
  AgeGroup: string
  IsPED: boolean
  DateOfBirth: string

  protected setData(res: any) {
    this.AgeGroup = res.ageGroup ?  res.ageGroup : (res.AgeGroup) ? res.AgeGroup : '';
    this.IsPED = res.isPED ? res.isPED : (res.IsPED) ? res.IsPED : false;
    this.DateOfBirth = res.dateOfBirth ? Utility.formatDate(res.dateOfBirth) : (res.DateOfBirth) ? Utility.formatDate(res.DateOfBirth) : "";
  }

  public static withAPIData(res: any): Traveller {
    let obj = new Traveller();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
  public static withAPIDataArray(res): Traveller[] {
    let travellerList: Traveller[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: Traveller;
        obj = Traveller.withAPIData(res[i]);
        travellerList.push(obj);
      }
    }
    return travellerList;
  }
}
