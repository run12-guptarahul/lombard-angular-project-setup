import { ContactDropLeadRequestModel } from './contact-drop-lead-request-model';

describe('ContactDropLeadRequestModel', () => {
  it('should create an instance', () => {
    expect(new ContactDropLeadRequestModel()).toBeTruthy();
  });
});
