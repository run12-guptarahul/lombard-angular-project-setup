export class MediaInfo {
  Media: string;
  Contact: string;
}

export class AuthVerifyInfo {
  Key: string;
  Value: string;
}

export class LoginRequestModel {
  RequestId: string;
  Transaction: string;
  ProductCode: string;
  Media: MediaInfo[];
  AuthVerifyInfo: AuthVerifyInfo[];
}

export class OtpRequest {
  OtpId: string;
  Otp: string;
}

