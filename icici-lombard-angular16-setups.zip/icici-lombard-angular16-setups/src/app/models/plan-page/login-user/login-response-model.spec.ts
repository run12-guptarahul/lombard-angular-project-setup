import { LoginResponseModel } from './login-response-model';

describe('LoginResponseModel', () => {
  it('should create an instance', () => {
    expect(new LoginResponseModel()).toBeTruthy();
  });
});
