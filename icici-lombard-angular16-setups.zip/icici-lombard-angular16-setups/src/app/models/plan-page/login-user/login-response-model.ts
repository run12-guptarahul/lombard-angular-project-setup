import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class LoginResponseModel extends BaseUIResponseModel {
    otpId:string;

protected override setData(res: any) {
  this.otpId = res.OtpId ? res.OtpId : "";
  super.setData(res);
  }
  public static override withAPIData(res: any): LoginResponseModel {
    let obj = new LoginResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    return obj;
  }
}
