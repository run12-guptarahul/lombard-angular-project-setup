import { TravelUIDataModel } from "../session-storage/travel-ui-data-model";
import { Traveller } from "./contact-drop/contact-drop-lead-request-model";
import { CountryMasterResponseModel } from "./country/country-master-response-model";
import { PlanConfigurationModel } from "./premium/plans/plan-configuration/plan-configuration-model";
import { PlanMasterCover } from "./premium/plans/plan-master-cover/plan-master-cover";
import { PlanCoverGroupPremium, PlanCoverPremium, PremiumResponseModel } from "./premium/premium/premium-response-model";

export class PlanUIModel {
  proposalId: string[] = [];
  getPremiumData: PremiumResponseModel[] = [];
  requestId: string;
  planData: PlanConfigurationModel[];
  isExpressCheckout: boolean;
  totalPremium: number;
  basicPremium: number;
  gst: number;
  sumInsured: number;
  activePlanDefaultSI: number = 0;
  mobileNo: string;
  emailId: string;
  coverGroupCodeList: string[];
  planCode: string;
  sumInsuredList: SIData[];
  selectedCountyGeographyData: CountyGeographyData;
  landingURL: string;
  travelStarteDate: string;
  travelEndDate: string;
  geoGraphy: string;
  countryNameList: string[];
  tripType: string;
  travellerType: string;
  isSeniorCitizen: boolean;
  benefitCoverList: PlanMasterCover[];
  isBuyNow: boolean;
  travellers: Traveller[];
  adultTravellers: Traveller[] = [];
  seniorTravellers: Traveller[] = [];
  tripDuration: number;
  callCalculatePremium: boolean;
  seniorCitizenPlanCode: string;
  seniorCitizenPremium: number;
  isOnlySeniorPLan: boolean = false;
  isExpressCheckOutVerify: boolean = false;
  isSIChange: boolean;
  
  public static setUIData(travelUIData: TravelUIDataModel[], planUIModel: PlanUIModel): PlanUIModel {
    let obj = planUIModel;
    if (planUIModel != undefined && planUIModel != null) {
      obj.landingURL = travelUIData[0].landingURL;
      obj.travelStarteDate = travelUIData[0].tripStartDate;
      obj.travelEndDate = travelUIData[0].tripEndDate;
      obj.geoGraphy = travelUIData[0].geography ? travelUIData[0].geography : "";
      obj.countryNameList = travelUIData[0].visitingCountry ? travelUIData[0].visitingCountry : [];
      obj.tripType = (travelUIData[0].tripType == 'SINGLE')? "Single Trip":"Multi Trip";
      obj.travellerType = travelUIData[0].travellerType;
      obj.sumInsured = planUIModel.sumInsured ? planUIModel.sumInsured : null;
      obj.emailId = travelUIData[0].emailId;
      obj.mobileNo = travelUIData[0].mobileNo;
      obj.travellers = Traveller.withAPIDataArray(travelUIData[0].travellers);
      obj.tripDuration = travelUIData[0].tripDuration;
      obj.landingURL = travelUIData[0].landingURL ? travelUIData[0].landingURL : "";
          }
    return obj;
  }
}

export class SIData {
  SI: number;
  disabled: boolean;
  isActive: boolean;
  constructor(SI: number, flag: boolean, isActive: boolean) {
    this.SI = SI;
    this.disabled = flag;
    this.isActive = isActive;
  }
}
export class CountyGeographyData {
  geography: string;
  country: string[];
  constructor(geography: string, country: any[]) {
    this.geography = geography;
    this.country = country;

  }


}
export class plan {
  planCode: string;
  planType: boolean;
  constructor(planCode: string, planType: boolean) {
    this.planCode = planCode;
    this.planType = planType;
  }
}

