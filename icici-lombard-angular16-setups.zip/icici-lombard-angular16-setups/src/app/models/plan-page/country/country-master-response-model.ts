import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class CountryMasterResponseModel extends BaseUIResponseModel {
  
  country?: string;
  geography?: string;
  isPopular: number;
  displaySequence: number;
  
  protected override setData(res: any) {
    this.country = res.country ? res.country : res.Country;
    this.geography = res.geography ? res.geography : res.Geography;
    this.isPopular = res.isPopular ? res.isPopular : res.IsPopular;
    this.displaySequence = res.displaySequence ? res.displaySequence : res.DisplaySequence;
  }
    

  public static override withAPIData(res: any): CountryMasterResponseModel {
    let obj = new CountryMasterResponseModel();
    if (res != undefined && res != null) {
      obj.setData(res);
    }
    
    return obj;
  }
  public static withAPIDataArray(res): CountryMasterResponseModel[] {
    let CountryMasterList: CountryMasterResponseModel[] = [];
    if (res != undefined && res != null && res.length > 0) {
      for (let i = 0; i < res.length; i++) {
        let obj: CountryMasterResponseModel;
        obj = CountryMasterResponseModel.withAPIData(res[i]);
        obj.success = res.success ? res.success :res.Success;
        CountryMasterList.push(obj);
      }
    }
    return CountryMasterList;
  }
}
