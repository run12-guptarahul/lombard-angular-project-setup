import { CountryMasterResponseModel } from './country-master-response-model';

describe('CountryMasterResponseModel', () => {
  it('should create an instance', () => {
    expect(new CountryMasterResponseModel()).toBeTruthy();
  });
});
