import { BaseUIResponseModel } from "../../base/base-ui-response-model";

export class OtpResponseModel extends BaseUIResponseModel {
  firstName: string | null;
  lastName: string | null;
  lastLogin: string;
  passcode: string;
  expiry: string;

    protected override setData(res: any) {
        this.firstName = res.firstName ? res.firstName : (res.FirstName) ? res.FirstName :'';
      this.lastName = res.lastName ? res.lastName : (res.LastName) ? res.LastName : '';
      this.lastLogin = res.LastLogin ? res.lastLogin : (res.LastLogin) ? res.LastLogin : '';
      this.passcode = res.passcode ? res.passcode : (res.Passcode) ? res.Passcode : '';
      this.expiry = res.expiry ? res.expiry : (res.Expiry) ? res.Expiry : '';
      super.setData(res);
      }
    
      public static override withAPIData(res: any): OtpResponseModel {
        let obj = new OtpResponseModel();
        if (res != undefined && res != null) {
          obj.setData(res);
        }
        return obj;
      }
}



