export class OtpRequestModel {
    OtpId:string;
    Otp:string;
}
