import { OtpResponseModel } from './otp-response-model';

describe('OtpResponseModel', () => {
  it('should create an instance', () => {
    expect(new OtpResponseModel()).toBeTruthy();
  });
});
