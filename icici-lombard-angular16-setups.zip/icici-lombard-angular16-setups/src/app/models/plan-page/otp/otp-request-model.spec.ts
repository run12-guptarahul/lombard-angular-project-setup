import { OtpRequestModel } from './otp-request-model';

describe('OtpRequestModel', () => {
  it('should create an instance', () => {
    expect(new OtpRequestModel()).toBeTruthy();
  });
});
