export class QuoteRequestModel {
    proposalId?: string;
}
