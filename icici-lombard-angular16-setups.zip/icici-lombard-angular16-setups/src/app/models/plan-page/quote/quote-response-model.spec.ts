import { QuoteResponseModel } from './quote-response-model';

describe('QuoteResponseModel', () => {
  it('should create an instance', () => {
    expect(new QuoteResponseModel()).toBeTruthy();
  });
});
