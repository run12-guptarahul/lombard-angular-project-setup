import { QuoteRequestModel } from './quote-request-model';

describe('QuoteRequestModel', () => {
  it('should create an instance', () => {
    expect(new QuoteRequestModel()).toBeTruthy();
  });
});
