import { BaseUIResponseModel } from "../../base/base-ui-response-model";
import { Traveller } from "../contact-drop/contact-drop-lead-request-model";
import { PlanCoverGroupPremium, PlanCoverPremium } from "../premium/premium/premium-response-model";

export class QuoteResponseModel extends BaseUIResponseModel{
  proposalId?: string;
  basePremium: number;
  gst: number;
  totalPremium: number;
  sumInsured: number;
  covers?: PlanCoverPremium[];
  coverGroups?: PlanCoverGroupPremium[];
  optionalCovers?: PlanCoverPremium[];
  tripType?: string;
  geography?: string;
  visitingCountry?: string[];
  tripStartDate?: string;
  tripEndDate?: string;
  isNonImmigrantVisa: boolean;
  travellers?: Traveller[];
}
