import { PlanUIModel } from './plan-ui-model';

describe('PlanUIModel', () => {
  it('should create an instance', () => {
    expect(new PlanUIModel()).toBeTruthy();
  });
});
