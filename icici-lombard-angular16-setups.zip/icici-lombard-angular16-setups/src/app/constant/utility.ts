import * as CryptoJS from "crypto-js";
import { eChannelConfig } from "./configuration";
import { FormControl } from "@angular/forms";
import { emailFilterOne, emailFilterTwo } from 'src/app/constant/custom-validator';
import { EncryptedKvUIModel } from "src/app/models/token/token-response-model";
import { environment } from "src/app/environments/environment";
import JSEncrypt from "jsencrypt";
import { CORELATION_ID } from "src/app/constant/constants";

declare var $: any;
export class Utility {

  public static ageSlab: string;

  public static IsNullOrEmpty(input: any): boolean {
    if (input === null || input === "" || input === undefined || input.length <= 0)
      return true;
    else
      return false;
  }

  public static calculateAgeInYear(month: number, date: number, year: number): number {
    const today = new Date();
    let dateString = year.toString() + "-" + month.toString() + "-" + date.toString() + " 00:00:00";
    let birthDate: Date = new Date(dateString.replace(/-/g, '/'));
    return this.AgeCalculation(birthDate);

  }

  public static AgeCalculation(birthDate: Date): number {

    const today = new Date();
    let age: number = today.getFullYear() - birthDate.getFullYear();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    return age;
  }

  public static AgeCalculationNew(birthDate: Date, minYr, maxYr): number {
    const today = new Date();
    let age: number = today.getFullYear() - birthDate.getFullYear();
    let days = today.getDate() - birthDate.getDate();
    const m = today.getMonth() - birthDate.getMonth();
    if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
      age--;
    }
    if (age >= minYr) {
      if (age >= maxYr && days > 0) {    // for exact dob match
        age++;
      }
    }

    return age;
  }


  public static getddMMyyyyformat(date: any) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [day, month, year].join('/');
  };

  public static getMMddyyyyformat(date: any) {
    var d = new Date(date),
      month = '' + (d.getMonth() + 1),
      day = '' + d.getDate(),
      year = d.getFullYear();
    if (month.length < 2) month = '0' + month;
    if (day.length < 2) day = '0' + day;

    return [month, day, year].join('/');
  };

  public static isJson(data: string): boolean {
    try {
      JSON.parse(data);
      return true;
    } catch {
      return false;
    }
  }

  /**
   * 
   * @param sessionKeyName
   */
  public static retrieveSessionData(sessionKeyName: string): any {
    const sessionData = window.sessionStorage.getItem(sessionKeyName);
    if (sessionData !== null && this.isJson(sessionData))
      return JSON.parse(sessionData);
    else
      return sessionData;
  }

  /**
   * 
   * @param mobileNo
   */
  public static isValidMobileNo(mobileNo: string): boolean {
    const mobileFilter = /^([6-9]{1}[0-9]{9})$/;
    mobileNo = this.IsNullOrEmpty(mobileNo) ? mobileNo : mobileNo.toString().trim();

    return mobileFilter.test(mobileNo);
  }

  /**
   * 
   * @param dd
   * @param mm
   * @param yy
   */
  public static validateLeapYear(dd: number, mm: number, yy: number): boolean | undefined {
    if (mm == 0 || mm > 12)
      return false;
    if (dd == 0 || dd > 31)
      return false;

    if (mm == 2) {
      if (dd <= 28) {
        return true;
      } else if (dd == 29 && yy % 4 == 0) {
        return true;
      }
      else {
        return false;
      }
    }
    else {
      true;
    }
  }

  /**
   * 
   * @param dd
   * @param mm
   * @param yy
   * @param startAge
   * @param endAge
   */
  public static isValidAgeSlab(dd: number, mm: number, yy: number, startAge: number, endAge: number): boolean {
    let age: number = this.calculateAgeInYear(mm, dd, yy);
    if (age >= startAge && age <= endAge)
      return true;
    else
      return false;
  }

  /**
   *
   * @param dob
   * @param maxYr
   * @param minYr
   * @param maxMonth
   * @param minMonth
   * @param maxDay
   * @param minDay
   */
  public static isValidDOB(dob: string, minYr: number, maxYr: number, minMonth: number, maxMonth: number, minDay: number, maxDay: number) {
    var dateRegex = /^(?=\d)(?:(?:31(?!.(?:0?[2469]|11))|(?:30|29)(?!.0?2)|29(?=.0?2.(?:(?:(?:1[6-9]|[2-9]\d)?(?:0[48]|[2468][048]|[13579][26])|(?:(?:16|[2468][048]|[3579][26])00)))(?:\x20|$))|(?:2[0-8]|1\d|0?[1-9]))([-.\/])(?:1[012]|0?[1-9])\1(?:1[6-9]|[2-9]\d)?\d\d(?:(?=\x20\d)\x20|$))?(((0?[1-9]|1[012])(:[0-5]\d){0,2}(\x20[AP]M))|([01]\d|2[0-3])(:[0-5]\d){1,2})?$/;
    var MaxDate = new Date();
    MaxDate.setFullYear(MaxDate.getFullYear() - (maxYr));
    MaxDate.setMonth(MaxDate.getMonth() - (maxMonth));
    MaxDate.setDate(MaxDate.getDate() - (maxDay));
    MaxDate = new Date(MaxDate.toDateString());
    var MinDate = new Date();
    MinDate.setFullYear(MinDate.getFullYear() - (minYr));
    MinDate.setMonth(MinDate.getMonth() - (minMonth));
    MinDate.setDate(MinDate.getDate() - (minDay));
    MinDate = new Date(MinDate.toDateString());
    var birthDate = new Date(this.stringTODate((dob.trim().replace(/\-/g, '/'))));
    if (!dateRegex.test((dob.trim().replace(/\-/g, '/')))) {
      return false;
    }
    else if (!(birthDate >= MaxDate && birthDate <= MinDate)) {
      return false;
    }
    else {
      return true;
    }
  }

  /**
   *
   * @param date
   */
  public static stringTODate(date: string) {
    if (date != null && date != undefined) {
      let splitDate = date.split('/');
      let val = new Date(+splitDate[2], +splitDate[1] - 1, +splitDate[0]);
      return val;
    }
  }

  public static getClientIPAddress() {
    return "2405:204:e187:d206";
  }

  public static getDeviceId() {
    let deviceId = Utility.retrieveSessionData("deviceId");
    if (Utility.IsNullOrEmpty(deviceId)) {
      deviceId = "d1234";
    }
    return deviceId;
  }

  public static version() {
    return "v6.1.1"
  }


  public static getsId(): string {
    let sid = "";
    const storedSid = Utility.retrieveSessionData("SID");
    if (storedSid !== null && storedSid !== undefined) {
      sid = storedSid;
    }
    return sid;
  }

  public static getCorelationId(): any {
    var id = Utility.retrieveSessionData(CORELATION_ID);
    if (Utility.IsNullOrEmpty(id)) {
      id = this.generateCorelationId();
      window.sessionStorage.setItem(CORELATION_ID, id);
    }
    return id;
  }


  public static s4() {
    return Math.floor((1 + Math.random()) * 0x10000)
      .toString(16)
      .substring(1);
  }

  public static generateCorelationId() {
    return this.s4() + this.s4() + '-' + this.s4() + '-' + this.s4() + '-' +
      this.s4() + '-' + this.s4() + this.s4() + this.s4();
  }

  public static getUniqueNumber(length: any) {
    return Math.floor(Math.pow(10, length - 1) + Math.random() * (Math.pow(10, length) - Math.pow(10, length - 1) - 1)).toString();
  }

  public static getkvr() {
    return this.getUniqueNumber(16) + this.getUniqueNumber(16);
  }

  public static getEncryptedBody(input: any, kv: any) {
    var encrypted;
    input = JSON.stringify(input);
    if (!Utility.IsNullOrEmpty(kv)) {
      let kvq = kv.substring(0, 16);
      let ivq = kv.substring(16, 32);
      encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(input), CryptoJS.enc.Utf8.parse(kvq),
        {
          keySize: 128 / 8,
          iv: CryptoJS.enc.Utf8.parse(ivq),
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7
        });
    }
    return JSON.stringify(new EncryptedKvUIModel("e01" + encrypted));
  }

  public static createEncryptedKV(kv: any) {
    var publicKey = environment.PBK;
    var encryptor = new JSEncrypt({ default_key_size: "2048" });
    encryptor.setPublicKey(publicKey);
    var ciphertext = encryptor.encrypt(kv);
    return ciphertext.toString();
  }

  public static getApiBinding(): any {
    var d = new Date().toISOString();
    d = d.split(".")[0] + "Z";
    var input = eChannelConfig.ClientId + "|" + d;
    var encrypted = CryptoJS.AES.encrypt(CryptoJS.enc.Utf8.parse(input), CryptoJS.enc.Utf8.parse(eChannelConfig.CryptoKey),
      {
        keySize: 128 / 8,
        iv: CryptoJS.enc.Utf8.parse(eChannelConfig.CryptoIv),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7
      });
    return encrypted.toString();
  };

  public static GetUrlParameter(url: string): any {
    var outParam = new RegExp('[\?&]' + url + '=([^&#]*)', 'i').exec(window.location.href);
    if (outParam == null)
      return null;
    else
      return decodeURIComponent(outParam[1]) || "0";
  }

  encryptionBody(input: string, kv: string): any {
    if (kv != undefined && kv != null && kv != '') {
      let kvq = kv.substring(0, 16);
      let ivq = kv.substring(16, 32);
      let encryptString = CryptoJS.AES.encrypt(
        CryptoJS.enc.Utf8.parse(input),
        CryptoJS.enc.Utf8.parse(kvq),
        {
          keySize: 128 / 8,
          iv: CryptoJS.enc.Utf8.parse(ivq),
          mode: CryptoJS.mode.CBC,
          padding: CryptoJS.pad.Pkcs7,
        }
      );
      return JSON.stringify(new EncryptedKvUIModel("e01" + encryptString));
    } else {
      return this.encryptionWithoutSalt(input);
    }
  }

  KeyIv() {
    return 'xxxxxxxxxxxx4xxxyxxxxxxxxxxxxxxx'
      .replace(/[xy]/g, function (c) {
        const r = Math.random() * 16 | 0,
          v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
      });
  }

  //KV encryption method


  public encryptionWithoutSalt(input: string): any {
    let encryptString = CryptoJS.AES.encrypt(
      CryptoJS.enc.Utf8.parse(input),
      CryptoJS.enc.Utf8.parse(eChannelConfig.CryptoKey),
      {
        keySize: 128 / 8,
        iv: CryptoJS.enc.Utf8.parse(eChannelConfig.CryptoIv),
        mode: CryptoJS.mode.CBC,
        padding: CryptoJS.pad.Pkcs7,
      }
    );
    return encryptString;
  }

  public GetuniqueNumber(length: number): string {
    return Math.floor(
      Math.pow(10, length - 1) +
      Math.random() * (Math.pow(10, length) - Math.pow(10, length - 1) - 1)
    ).toString();
  }

  public getCorrelationId(): string {
    return Math.floor((1 + Math.random()) * 0x1000)
      .toString(16)
      .substring(1);
  }

  public validateEmail(c: FormControl) {
    const emailRegexOne = emailFilterOne;
    const emailRegexTwo = emailFilterTwo;
    if (emailRegexOne.test(c.value) && emailRegexTwo.test(c.value)) {
      return null;
    } else {
      return {
        pattern: {
          valid: false,
        },
      };
    }
  }
  public static gstNoValidate(value: string): boolean {
    let IsValid = false;
    let reggst = /^([0-9]){2}([a-zA-Z]){3}([P|C|H|A|B|G|J|L|E|F|T]){1}([A-Z]){1}([0-9]){4}([a-zA-Z]){1}([A-Z1-9]){1}([A-J1-9Z]){1}([A-Z0-9]){1}?$/;
    if (reggst.test(value) && value != '' && value.length == 15) {
      return IsValid = true;
    }
    return IsValid;
  }

  public static formatDate(inputDate: string): string {
    // Split the input date assuming it's in DD-MM-YYYY format
    const dateParts = inputDate.split('/');

    if (dateParts.length !== 3) {
      return 'Invalid date'; // Handle invalid date format
    }

    const day = parseInt(dateParts[2], 10);
    const month = parseInt(dateParts[1], 10) - 1; // Month is zero-indexed in JavaScript
    const year = parseInt(dateParts[0], 10);

    // Check if the parsed values are valid
    if (isNaN(day) || isNaN(month) || isNaN(year)) {
      return 'Invalid date';
    }

    // Create a Date object using the manually parsed values
    const date = new Date(year, month, day);

    // Validate the date to make sure it's real (e.g., no Feb 30)
    if (isNaN(date.getTime())) {
      return 'Invalid date';
    }

    // Define month abbreviations
    const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

    // Format the date as DD-MMM-YYYY
    const formattedDate = `${day.toString().padStart(2, '0')}-${months[month]}-${year}`;

    return formattedDate;
  }

}
