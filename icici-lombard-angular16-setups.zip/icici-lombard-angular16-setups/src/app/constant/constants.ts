
// token related variable decalre start here
var BASE_URL: string = "/eChannelServices/api";
export var GENERATE_TOKEN: string = BASE_URL + "/Auth/token";

//Auth contstant value
export var AUTH_TOKEN = "AuthorizationToken";
export var AUTH_TOKEN_EXPIRY = "TokenExpiry";
export var TOKEN_ID = "TokenId";

//Guest user constant session storage
export var LOGIN_TYPE = "LoginType";
export var IS_GUEST_USER = "IsGuestUser";
export var CALLED_GUEST_TOKEN = "IsCalledGuestUserToken";
export var CORELATION_ID: string = "Corelationid";
export var IS_PROPOSAL_OTP_AUTH = "isProposalOTPAuth";

export var SHOW_NETWORK_ERROR: string = "showNetworkError";
export var NETWORK_STATUS_CODE: string = "400,401,403,404,500,502,503,504";
export var NO_LOADER: string = "no-loader";
export var NO_ENCRYPTION: string = "no-encryption";

// token related variable decalre end here



// product related logic variable start here

export var DATECONTROL = "dateFormat";
export var OTPCONTROL = 'phoneOTP';

//session storage
export var PROPOSAL_ID = "ProposalId";
export var RN_HEALTH_UI_Data = "RNhealthUIData"
export var POLICYTYPE = "policyType";
export var URL_PROPOSAL_ID = "p1";
export var URL_PROPOSAL_ID1 = "p2";

// product related logic variable End here

export var CUSTOMER: string = 'customer';
export var INSURED_MEMBER: string = 'insured-member';
export var EMERGENCY_DETAIL: string = 'emergency-detail';
export var REQUEST_ID = "RequestID";
export var CUSTOMER_MOBILE = "customerMobile";
export var CUSTOMER_EMAIL = "customerEmail";


export var MIN_MAX_AGE = {
    INSURED_ADULT: {
      MIN_DAY: 0,
      MAX_DAY: 364,
      MIN_MONTH: 0,
      MAX_MONTH: 0,
      MIN_YEAR: 0,
      MAX_YEAR: 70,
    },
    INSURED_SENIOR: {
      MIN_DAY: 91,
      MAX_DAY: 364,
      MIN_MONTH: 0,
      MAX_MONTH: 0,
      MIN_YEAR: 0,
      MAX_YEAR: 30,
    },
    APPLICANT: {
      MIN_DAY: 0,
      MAX_DAY: 364,
      MIN_MONTH: 0,
      MAX_MONTH: 0,
      MIN_YEAR: 18,
      MAX_YEAR: 100,
    },
    NOMINEE: {
      MIN_DAY: 0,
      MAX_DAY: 364,
      MIN_MONTH: 0,
      MAX_MONTH: 0,
      MIN_YEAR: 18,
      MAX_YEAR: 100,
    }
  }
    
  export var PRODUCT_CODE = 3837;
  
 
  
