import { Validators } from "@angular/forms";

//Form validations
export var nameValidation = [
  Validators.required,
  Validators.pattern('^[a-zA-Z \-\']+'),
  Validators.maxLength(40),
  Validators.minLength(3)
]

export var phoneNumberValidation = [
    Validators.required,
    Validators.pattern('^[^0-5][^/S][0-9]{8}$'),
    Validators.maxLength(10),
    Validators.minLength(10),
]

export var pincodeValidation = [
    Validators.required,
    Validators.maxLength(6),
    Validators.minLength(6)
]

export var emailValidation = [
    Validators.required,
    Validators.pattern('^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,4}$'),
]


export var gstNoValidation = [
  Validators.required,
  //Validators.pattern("^([0-9]){2}([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}([a-zA-Z0-9]){1}([a-zA-Z]){1}([a-zA-Z0-9]){1}?$"),
  Validators.pattern(/^([0-9]){2}([a-zA-Z]){3}([P|C|H|A|B|G|J|L|E|F|T]){1}([A-Z]){1}([0-9]){4}([a-zA-Z]){1}([A-Z1-9]){1}([A-J1-9Z]){1}([A-Z0-9]){1}?$/),
  Validators.minLength(15),
  Validators.maxLength(15),
]
export var panNoValidation = [
  Validators.required,
  Validators.pattern("^[A-Z]{5}[0-9]{4}[A-Z]{1}$"),
  Validators.minLength(10),
  Validators.maxLength(10),
]
export var addressValidation = [
  Validators.pattern(/^[#.0-9a-zA-Z-+=&<> ^\\s,',",;,:,?,+,/,_,|()]+$/),
]

export var paAnualIncomeValidation = [
  Validators.required,
  Validators.minLength(1),
  Validators.maxLength(9),
  Validators.max(250000000)
]

export const emailFilterOne = /^(([^|\\<>/()\[\]\,;:@\"]+(\[^<>()\[\]\,;:\s@\"])*)|(\"\"))@(([^<>()[\]\.,;:\s@\"]+\.)+[^0-9<>/()[\]\.,;:\s@\"]{2,4})$/;
export const emailFilterTwo = /^([a-zA-Z0-9_.-])+\@(([a-zA-Z0-9-]{2,9})+\.)+([a-zA-Z0-9]{2,4})+$/;

