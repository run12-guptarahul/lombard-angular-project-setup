export class eChannelConfig {

  public static BaseUrl = "/eChannelServices/api/"; //Base Url for api call
  //public static BaseUrl: string = "http://localhost:9067/api/"; //Base Url for api call
  public static BaseUrlforOldUI = "/IpartnerService/core/api/"; //Base Url for api call
  public static BaseUrlforUIUX = "/ipartner_web/api/"; //Base Url for api call
  public static MicroServicesBaseUrl = "/digital/v2.0/";

  ///////////////////////token related configuration code start here //////////////////////////////////
  public static AUTH_URL: string = "/digital/v2.0/auth-api/client/initialize";
  public static REFRESH_URL = "/echannelServices/api/Auth/token/refresh";
  public static WEB_TOKEN_URL = "/echannelServices/api/web-link/";
  
  public static GuestUserTokenUrl = eChannelConfig.MicroServicesBaseUrl + "auth-api/client/guest";
  public static CryptoKey = "7080808080808083";
  public static CryptoIv = "9080808080808083";
  public static ClientId = window.sessionStorage.getItem("clientId") == (null || undefined) ? 1 : window.sessionStorage.getItem("clientId");
  public static AuthToken = window.sessionStorage.getItem("AuthorizationToken") == (null || undefined) ? "" : window.sessionStorage.getItem("AuthorizationToken");
  public static gclId = window.sessionStorage.getItem("gclid") == (null || undefined) ? "" : window.sessionStorage.getItem("gclid");
  public static efId = window.sessionStorage.getItem("ef_id") == (null || undefined) ? "" : window.sessionStorage.getItem("ef_id");
  ///////////////////////token related configuration code end here  //////////////////////////////////


  
  ////////////////////////////// project related API URL Configuration start here ///////////////////////////
  public static PINCODE_URL = eChannelConfig.BaseUrl + "Master/CityDistrict/PinCode/";
  public static PLAN_COUNTRY_LIST = eChannelConfig.MicroServicesBaseUrl + "travel-api/Country";
  public static PLAN_MASTER_COVER_LIST = eChannelConfig.MicroServicesBaseUrl + "travel-api/Covers";
  public static PLANS_URL = eChannelConfig.MicroServicesBaseUrl + "travel-api/Plans";
  public static CALCULATE_PREMIUM_URL = eChannelConfig.MicroServicesBaseUrl + "travel-api/premium";
  public static FETCH_QUOTE_URL = eChannelConfig.MicroServicesBaseUrl + "travel-api/getpremium";
  public static GUEST_TOKEN_URL = "/digital/v2.0/auth-api/client/guest";
  public static FETCH_PROPOSAL_URL = eChannelConfig.MicroServicesBaseUrl + "travel-api/getproposal";
  public static SAVE_PROPOSAL_URL = eChannelConfig.MicroServicesBaseUrl + "travel-api/Proposal";
  public static GET_PED_LIST = eChannelConfig.MicroServicesBaseUrl + "travel-api/ped";
  public static GET_RELATIONSHIP_WITH_APPLICANT_URL = eChannelConfig.MicroServicesBaseUrl + "travel-api/relationship-with-applicant";
  public static GET_RELATIONSHIP_WITH_NOMINEE_URL = eChannelConfig.MicroServicesBaseUrl + "travel-api/relationship-with-nominee";

  public static LOGIN_USER_URL = eChannelConfig.MicroServicesBaseUrl + "auth-api/generic/otp";
  public static VERIFY_OTP_URL = eChannelConfig.MicroServicesBaseUrl + "auth-api/otp/validate";


  ////////////////////////////// project related API URL Configuration start here ///////////////////////////


  // public static ZONE_URL = "/digital/v2.0/elevate-api/Proposal/getzone";
  public static GET_CUSTOMER_PROFILE: string = "/echannelServices/api/Customer/Profile/";
  public static GET_CUSTOMER_KYC_URL: string = "/digital/v2.0/customer-api/customer";
  public static CREATE_CUSTOMER_URL = "/digital/v2.0/customer-api/customer/create";



  
 
}


