export var planAPI = {
  "errorId": 0,
  "success": true,
  "statusCode": 0,
  "technicalError": "No errors",
  "displayMessage": "Operation successful",
  "corelationId": "abc123",
  "plans": [
    {
      "planCode": "essential_plan_1",
      "displayName": "Essential Plan",
      "isRecommended": false,
      "isDefault": false,
      "displaySequence": 1,
      "description":"Comprehensive trip protection",
      "sumInsured": [
        50, 100,100,100,250,500
      ],
      "defaultSumInsured": 100,
      "bottomTipText": "Essential Essential  Essential",
      "covers": [
        {
          "coverCode": "essential_cover_1",
          "displaySequence": 1
        },
        {
          "coverCode": "essential_cover_2",
          "displaySequence": 2
        },
        {
          "coverCode": "essential_cover_3",
          "displaySequence": 3
        },
        {
          "coverCode": "essential_cover_4",
          "displaySequence": 4
        },
        {
          "coverCode": "essential_cover_5",
          "displaySequence": 5
        },
        {
          "coverCode": "C1",
          "displaySequence": 6
        }
      ],
      "coverGroups": [
        {
          "coverGroupCode": "Cruise_Guard1",
          "displayName": "Cruise Guard (Essential)",
          "description": "Get hassle-free car rental insurance 111",
          "proTipText": "",
          "heroFeatureImagePath": "/images/health.png",
        },
        {
          "coverGroupCode": "Booking_Guard1",
          "displayName": "Booking Guard (Essential)",
          "description": "Keeping your funds is SAFE, on every trip 222",
          "proTipText": "18% tourists in Asia hit by financial fraud",
          "heroFeatureImagePath": "",
        },
        {
          "coverGroupCode": "Adventure_Sports1",
          "displayName": "Adventure Sports(Essential)",
          "description": "Secure your trip from start to finish 333",
          "proTipText": "",
          "heroFeatureImagePath": "",
        },
        {
          "coverGroupCode": "Car_Rental1",
          "displayName": "Car Rental (Essential)",
          "description": "Protecting your health, wherever you go 444",
          "proTipText": "Stay protected on the road",
          "heroFeatureImagePath": "",
        }
      ]
    },
    {
      "planCode": "prime_plan_1",
      "displayName": "prime Plan",
      "isRecommended": true,
      "isDefault": true,
      "displaySequence": 2,
      "description":"Enhanced Protection, Extra Benefits",
      "sumInsured": [
        250, 500, 1000
      ],
      "defaultSumInsured": 500,
      "bottomTipText": "5k+ travelers are protected this season",
      "covers": [
        {
          "coverCode": "prime_cover_1",
          "displaySequence": 1
        },
        {
          "coverCode": "prime_cover_2",
          "displaySequence": 2
        },
        {
          "coverCode": "prime_cover_3",
          "displaySequence": 3
        },
        {
          "coverCode": "prime_cover_4",
          "displaySequence": 4
        },
        {
          "coverCode": "prime_cover_5",
          "displaySequence": 5
        }
      ],
      "coverGroups": [
        {
          "coverGroupCode": "Cruise_Guard11",
          "displayName": "Cruise Guard(prime)",
          "description": "Get hassle-free car rental insurance ###",
          "proTipText": "",
          "heroFeatureImagePath": "/images/health.png",
        },
        {
          "coverGroupCode": "Booking_Guard11",
          "displayName": "Booking Guard(prime)",
          "description": "Keeping your funds is SAFE, on every trip ##",
          "proTipText": "18% tourists in Asia hit by financial fraud",
          "heroFeatureImagePath": "",
        },
        {
          "coverGroupCode": "Adventure_Sports11",
          "displayName": "Adventure Sports(prime)",
          "description": "Secure your trip from start to finish $$$",
          "proTipText": "",
          "heroFeatureImagePath": "",
        },
        {
          "coverGroupCode": "Car_Rental11",
          "displayName": "Car Rental(prime)",
          "description": "Protecting your health, wherever you go $$$",
          "proTipText": "Stay protected on the road",
          "heroFeatureImagePath": "",
        }
      ]
    },
    {
      "planCode": "adventure_plan_1",
      "displayName": "Adventure Plan",
      "isRecommended": false,
      "isDefault": false,
      "displaySequence": 3,
      "description":"Comprehensive trip protection",
      "sumInsured": [
        2000, 3000,100
      ],
      "defaultSumInsured": 3000,
      "bottomTipText": "Adventure Adventure Adventure",
      "covers": [
        {
          "coverCode": "adventure_cover_1",
          "displaySequence": 1
        },
        {
          "coverCode": "adventure_cover_2",
          "displaySequence": 2
        },
        {
          "coverCode": "adventure_cover_3",
          "displaySequence": 3
        },
        {
          "coverCode": "adventure_cover_4",
          "displaySequence": 4
        },
        {
          "coverCode": "adventure_cover_5",
          "displaySequence": 5
        }
      ],
      "coverGroups": [
        {
          "coverGroupCode": "Cruise_Guard22",
          "displayName": "Cruise Guard testing(Adventure)",
          "description": "Get hassle-free car rental insurance @@@",
          "proTipText": "",
          "heroFeatureImagePath": "/images/health.png",
        },
        {
          "coverGroupCode": "Booking_Guard22",
          "displayName": "Booking Guard testing(Adventure)",
          "description": "Keeping your funds is SAFE, on every trip @@@",
          "proTipText": "18% tourists in Asia hit by financial fraud",
          "heroFeatureImagePath": "",
        },
        {
          "coverGroupCode": "Adventure_Sports22",
          "displayName": "Adventure Sports testing(Adventure)",
          "description": "Secure your trip from start to finish @@",
          "proTipText": "",
          "heroFeatureImagePath": "",
        },
        {
          "coverGroupCode": "Car_Rental22",
          "displayName": "Car Rental testing(Adventure)",
          "description": "Protecting your health, wherever you go @@@",
          "proTipText": "Stay protected on the road",
          "heroFeatureImagePath": "",
        }
      ]
    }
  ],
  "isExpressCheckout": false
}

export var MasterCoverAPI = [
  {
    "coverCode": "essential_cover_1",
    "coverShortName": "ShortName1",
    "coverSection": "essential cover 1",
    "coverType": "Medical Cover",
    "coverBenefit": "Benefit1"
  },
  {
    "coverCode": "essential_cover_2",
    "coverShortName": "ShortName2",
    "coverSection": "essential cover 2",
    "coverType": "Medical Cover",
    "coverBenefit": "Benefit2"
  },
  {
    "coverCode": "essential_cover_3",
    "coverShortName": "ShortName3",
    "coverSection": "essential cover 3",
    "coverType": "Baggage & Personal",
    "coverBenefit": "Benefit3"
  },
  {
    "coverCode": "essential_cover_4",
    "coverShortName": "ShortName4",
    "coverSection": "essential cover 4",
    "coverType": "Baggage & Personal",
    "coverBenefit": "Benefit4"
  },
  {
    "coverCode": "essential_cover_5",
    "coverShortName": "ShortName21",
    "coverSection": "essential cover 5",
    "coverType": "Baggage & Personal",
    "coverBenefit": "Benefit5"
  },
  {
    "coverCode": "prime_cover_1",
    "coverShortName": "ShortName22",
    "coverSection": "prime cover sds asd",
    "coverType": "other",
    "coverBenefit": "Benefit6"
  },
  {
    "coverCode": "prime_cover_2",
    "coverShortName": "ShortName100",
    "coverSection": "prime cover 1",
    "coverType": "other",
    "coverBenefit": "Benefit7"
  },
  {
    "coverCode": "prime_cover_3",
    "coverShortName": "ShortName101",
    "coverSection": "prime cover 2",
    "coverType": "other",
    "coverBenefit": "Benefit8"
  },
  {
    "coverCode": "prime_cover_4",
    "coverShortName": "ShortName102",
    "coverSection": "prime cover 3",
    "coverType": "Baggage & Personal",
    "coverBenefit": "Benefit9"
  },
  {
    "coverCode": "prime_cover_5",
    "coverShortName": "ShortName103",
    "coverSection": "prime cover 4",
    "coverType": "Medical Cover",
    "coverBenefit": "Benefit10"
  },
  {
    "coverCode": "adventure_cover_1",
    "coverShortName": "ShortName1",
    "coverSection": "adventure cover 1",
    "coverType": "Baggage & Personal",
    "coverBenefit": "Benefit1"
  },
  {
    "coverCode": "adventure_cover_2",
    "coverShortName": "ShortName2",
    "coverSection": "adventure cover 2",
    "coverType": "Medical Cover",
    "coverBenefit": "Benefit2"
  },
  {
    "coverCode": "adventure_cover_3",
    "coverShortName": "ShortName4",
    "coverSection": "adventure cover 3",
    "coverType": "Type4",
    "coverBenefit": "Benefit4"
  },
  {
    "coverCode": "adventure_cover_4",
    "coverShortName": "ShortName21",
    "coverSection": "adventure cover 4",
    "coverType": "Type5",
    "coverBenefit": "Benefit5"
  },
  {
    "coverCode": "adventure_cover_5",
    "coverShortName": "ShortName22",
    "coverSection": "adventure cover 5",
    "coverType": "Type6",
    "coverBenefit": "Benefit6"
  },
  {
    "coverCode": "C1",
    "coverShortName": "ShortName1",
    "coverSection": "Section1",
    "coverType": "Type1",
    "coverBenefit": "Benefit1"
  },
  {
    "coverCode": "C2",
    "coverShortName": "ShortName2",
    "coverSection": "Section2",
    "coverType": "Type2",
    "coverBenefit": "Benefit2"
  },
  {
    "coverCode": "C11",
    "coverShortName": "ShortName3",
    "coverSection": "Section3",
    "coverType": "Type3",
    "coverBenefit": "Benefit3"
  },
  {
    "coverCode": "C12",
    "coverShortName": "ShortName4",
    "coverSection": "Section4",
    "coverType": "Type1",
    "coverBenefit": "Benefit4"
  },
  {
    "coverCode": "C21",
    "coverShortName": "ShortName21",
    "coverSection": "Section5",
    "coverType": "Type1",
    "coverBenefit": "Benefit5"
  },
  {
    "coverCode": "C22",
    "coverShortName": "ShortName22",
    "coverSection": "Section6",
    "coverType": "Type1",
    "coverBenefit": "Benefit6"
  },
  {
    "coverCode": "C100",
    "coverShortName": "ShortName100",
    "coverSection": "Section7",
    "coverType": "Type1",
    "coverBenefit": "Benefit7"
  },
  {
    "coverCode": "C101",
    "coverShortName": "ShortName101",
    "coverSection": "Section8",
    "coverType": "Type1",
    "coverBenefit": "Benefit8"
  },
  {
    "coverCode": "C102",
    "coverShortName": "ShortName102",
    "coverSection": "Section9",
    "coverType": "Type1",
    "coverBenefit": "Benefit9"
  },
  {
    "coverCode": "C103",
    "coverShortName": "ShortName103",
    "coverSection": "Section10",
    "coverType": "Type1",
    "coverBenefit": "Benefit10"
  }
]

export var MasterCountryAPI = [
  {
    "country": "USA",
    "geography": "North America",
    "isPopular": 1,
    "displaySequence": 1
  },
  {
    "country": "Canada",
    "geography": "North America",
    "isPopular": 1,
    "displaySequence": 2
  },
  {
    "country": "Pakistan",
    "geography": "Asia",
    "isPopular": 1,
    "displaySequence": 3
  },
  {
    "country": "Germany",
    "geography": "Europe",
    "isPopular": 0,
    "displaySequence": 4
  },
  {
    "country": "Australia",
    "geography": "Oceania",
    "isPopular": 1,
    "displaySequence": 5
  },
  {
    "country": "Brazil",
    "geography": "South America",
    "isPopular": 1,
    "displaySequence": 6
  },
  {
    "country": "Japan",
    "geography": "Asia",
    "isPopular": 1,
    "displaySequence": 7
  },
  {
    "country": "France",
    "geography": "Europe",
    "isPopular": 0,
    "displaySequence": 8
  },
  {
    "country": "South Africa",
    "geography": "Africa",
    "isPopular": 0,
    "displaySequence": 9
  },
  {
    "country": "Shri Lanka",
    "geography": "ASIA",
    "isPopular": 1,
    "displaySequence": 10
  }
]


export var premiumResponseAPI = {
  "errorId": 0,
  "success": true,
  "statusCode": 0,
  "technicalError": "",
  "displayMessage": "Data fetched successfully",
  "corelationId": "ABC123",
  "proposalId": "XYZ456",
  "planCode":"prime_plan_1",
  "basePremium": 1000,
  "gst": 180,
  "totalPremium": 1180,
  "sumInsured": 1000,
  "covers": [
    {
      "coverCode": "C1",
      "displaySequence": 1,
      "premium": 100
    },
    {
      "coverCode": "C2",
      "displaySequence": 2,
      "premium": 200
    },
    {
      "coverCode": "C3",
      "displaySequence": 3,
      "premium": 300
    }
  ],
  "coverGroups": [
    {
      "coverGroupCode": "Cruise_Guard11",
      "displayName": "Cruise Guard(prime)",
      "description": "Get hassle-free car rental insurance ###",
      "proTipText": "",
      "heroFeatureImagePath": "/images/health.png",
      "premium": 100,
      "isOpted": true
    },
    {
      "coverGroupCode": "Booking_Guard11",
      "displayName": "Booking Guard(prime)",
      "description": "Keeping your funds is SAFE, on every trip ##",
      "proTipText": "18% tourists in Asia hit by financial fraud",
      "heroFeatureImagePath": "",
      "premium": 200,
      "isOpted": false
    },
    {
      "coverGroupCode": "Adventure_Sports11",
      "displayName": "Adventure Sports(prime)",
      "description": "Secure your trip from start to finish $$$",
      "proTipText": "",
      "heroFeatureImagePath": "",
      "premium": 500,
      "isOpted": false
    },
    {
      "coverGroupCode": "Car_Rental11",
      "displayName": "Car Rental(prime)",
      "description": "Protecting your health, wherever you go $$$",
      "proTipText": "Stay protected on the road",
      "heroFeatureImagePath": "",
      "premium": 300,
      "isOpted": false
    }
  ]
  
}

export var fetchQuoteAPI = {
  "errorId": 0,
  "success": true,
  "statusCode": 0,
  "technicalError": "",
  "displayMessage": "Data fetched successfully",
  "corelationId": "ABC123",
  "proposalId": "XYZ456",
  "planCode":"prime_plan_1",
  "basicPremium": 1000,
  "gst": 180,
  "totalPremium": 1180,
  "sumInsured": 250,
  "covers": [
    {
      "coverCode": "C1",
      "displaySequence": 1,
      "premium": 100
    },
    {
      "coverCode": "C2",
      "displaySequence": 2,
      "premium": 200
    },
    {
      "coverCode": "C3",
      "displaySequence": 3,
      "premium": 300
    }
  ],
  "coverGroups": [
    {
      "coverGroupCode": "CG001",
      "displayName": "Group 1",
      "description": "Description for Group 1",
      "ProTipText": "Pro tip for Group 1",
      "heroFeatureImagePath": "/images/group1.jpg",
      "premium": 300,
      "isOpted": true
    },
    {
      "coverGroupCode": "CG002",
      "displayName": "Group 2",
      "description": "Description for Group 2",
      "proTipText": "Pro tip for Group 2",
      "heroFeatureImagePath": "/images/group2.jpg",
      "premium": 400,
      "isOpted": false

    },
    {
      "coverGroupCode": "CG003",
      "displayName": "Group 3",
      "description": "Description for Group 3",
      "proTipText": "Pro tip for Group 3",
      "heroFeatureImagePath": "/images/group3.jpg",
      "premium": 500,
      "isOpted": true
    },
    {
      "coverGroupCode": "CG004",
      "displayName": "Group 4",
      "description": "Description for Group 4",
      "proTipText": "Pro tip for Group 4",
      "heroFeatureImagePath": "/images/group4.jpg",
      "premium": 600,
      "isOpted": true
    }
  ],
  "tripType": "string",
  "geography": "ASIA",
  "visitingCountry": [
    "Singapore","UK","USA"
  ],
  "tripStartDate": "2024/09/01",
  "tripEndDate": "2024/09/10",
  "isNonImmigrantVisa": true,
  "travellers": [
    {
      "ageGroup": "50",
      "isPED": false,
      "dateOfBirth": "1974-08-06T17:29:18.026Z"
    },
    {
      "ageGroup": "60",
      "isPED": false,
      "dateOfBirth": "1964-08-06T17:29:18.026Z"
    },
    {
      "ageGroup": "70",
      "isPED": false,
      "dateOfBirth": "1954-08-06T17:29:18.026Z"
    }
  ]
}


export var fetchProposalAPI = {
 "errorId": 0,
  "success": true,
  "statusCode": 0,
  "technicalError": "",
  "displayMessage": "Data fetched successfully",
  "corelationId": "ABC123",
  "proposalId": "XYZ456",
  "policyStartDate": "21-Aug-2024",
  "policyEndDate": "20-Aug-2025",
  "basicPremium": 1000,
  "gst": 180,
  "totalPremium": 1180,
  "sumInsured": 250,
  "covers": [
    {
      "coverCode": "C1",
      "displaySequence": 1,
      "premium": 100
    },
    {
      "coverCode": "C2",
      "displaySequence": 2,
      "premium": 200
    },
    {
      "coverCode": "C3",
      "displaySequence": 3,
      "premium": 300
    }
  ],
  "coverGroups": [
    {
      "coverGroupCode": "CG001",
      "displayName": "Group 1",
      "description": "Description for Group 1",
      "ProTipText": "Pro tip for Group 1",
      "heroFeatureImagePath": "/images/group1.jpg",
      "premium": 300,
      "isOpted": true
    },
    {
      "coverGroupCode": "CG002",
      "displayName": "Group 2",
      "description": "Description for Group 2",
      "proTipText": "Pro tip for Group 2",
      "heroFeatureImagePath": "/images/group2.jpg",
      "premium": 400,
      "isOpted": false

    },
    {
      "coverGroupCode": "CG003",
      "displayName": "Group 3",
      "description": "Description for Group 3",
      "proTipText": "Pro tip for Group 3",
      "heroFeatureImagePath": "/images/group3.jpg",
      "premium": 500,
      "isOpted": true
    },
    {
      "coverGroupCode": "CG004",
      "displayName": "Group 4",
      "description": "Description for Group 4",
      "proTipText": "Pro tip for Group 4",
      "heroFeatureImagePath": "/images/group4.jpg",
      "premium": 600,
      "isOpted": true
    }
  ],
  "optionalCovers": [
    {
      "coverCode": "",
      "displaySequence": 0,
      "premium": 0
    }
  ],
  "customerId": "",
  "travellers": [
    {
      "ageGroup": "50",
      "isPED": false,
      "dateOfBirth": "1974-08-06T17:29:18.026Z"
    },
    {
      "ageGroup": "60",
      "isPED": false,
      "dateOfBirth": "1964-08-06T17:29:18.026Z"
    },
    {
      "ageGroup": "70",
      "isPED": false,
      "dateOfBirth": "1954-08-06T17:29:18.026Z"
    }
  ],
  "emergencyContactName": "",
  "emergencyContactNumber": "",
  "expressCheckoutMembers": [
    {
      "ageGroup": "50",
      "isPED": false,
      "dateOfBirth": "1974-08-06T17:29:18.026Z"
    },
    {
      "ageGroup": "60",
      "isPED": false,
      "dateOfBirth": "1964-08-06T17:29:18.026Z"
    },
    {
      "ageGroup": "70",
      "isPED": false,
      "dateOfBirth": "1954-08-06T17:29:18.026Z"
    }
  ]
}

export var expressCheckoutMembersAPI = {
  "ExpressCheckoutMembers": [
      {
        "Name": "Pooja",
        "DateOfBirth": "19-Oct-2000",
        "Gender": "Female",
        "PassportNumber": "123456",
        "RelationshipWithApplicant": "Self",
        "NomineeName" : "Test",
        "RelationshipWithNominee": "Son",
        "IsPED": false,
        "PED": ""
      },
      {
        "Name": "Kiran",
        "DateOfBirth": "15-Aug-1990",
        "Gender": "Male",
        "PassportNumber": "2222222",
        "RelationshipWithApplicant": "Spouse",
        "NomineeName" : "Test",
        "RelationshipWithNominee": "Son",
        "IsPED": false,
        "PED": ""
      },
      {
        "Name": "Kumar",
        "DateOfBirth": "19-Oct-2001",
        "Gender": "Male",
        "PassportNumber": "3333333",
        "RelationshipWithApplicant": "Sister",
        "NomineeName" : "Test",
        "RelationshipWithNominee": "Son",
        "IsPED": true,
        "PED": ""
      },
      {
        "Name": "Shriyan",
        "DateOfBirth": "19-Oct-2001",
        "Gender": "Male",
        "PassportNumber": "3333333",
        "RelationshipWithApplicant": "Sister",
        "NomineeName" : "Test",
        "RelationshipWithNominee": "Son",
        "IsPED": true,
        "PED": ""
      },
      {
        "Name": "Shrihan",
        "DateOfBirth": "19-Oct-2001",
        "Gender": "Male",
        "PassportNumber": "3333333",
        "RelationshipWithApplicant": "Sister",
        "NomineeName" : "Test",
        "RelationshipWithNominee": "Son",
        "IsPED": true,
        "PED": ""
      }
    ]
}