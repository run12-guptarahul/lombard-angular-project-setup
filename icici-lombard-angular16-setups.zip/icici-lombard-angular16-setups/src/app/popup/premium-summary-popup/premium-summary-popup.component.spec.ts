import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PremiumSummaryPopupComponent } from './premium-summary-popup.component';

describe('PremiumSummaryPopupComponent', () => {
  let component: PremiumSummaryPopupComponent;
  let fixture: ComponentFixture<PremiumSummaryPopupComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PremiumSummaryPopupComponent]
    });
    fixture = TestBed.createComponent(PremiumSummaryPopupComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
