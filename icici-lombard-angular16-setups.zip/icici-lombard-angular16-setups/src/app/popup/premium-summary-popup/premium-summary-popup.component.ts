import { Component } from '@angular/core';

@Component({
  selector: 'app-premium-summary-popup',
  templateUrl: './premium-summary-popup.component.html',
  styleUrls: ['./premium-summary-popup.component.css']
})
export class PremiumSummaryPopupComponent {

}
