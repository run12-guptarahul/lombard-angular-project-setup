import { Component } from '@angular/core';

@Component({
  selector: 'app-compare-plan',
  templateUrl: './compare-plan.component.html',
  styleUrls: ['./compare-plan.component.css']
})
export class ComparePlanComponent {

}
