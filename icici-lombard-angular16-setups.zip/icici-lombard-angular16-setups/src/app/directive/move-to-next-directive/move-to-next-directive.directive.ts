import { Directive, HostListener, Input } from '@angular/core';
import * as Constants from 'src/app/constant/constants';

@Directive({
  selector: '[appMoveToNextDirective]'
})
export class MoveToNextDirectiveDirective {

  @Input() searchType: string;
  @Input() elementData: any;
 
  backspaceBehaviour: any = 0;
  behavior: any = 0;
  constructor() { }
 
  @HostListener('keydown', ['$event']) onKeypress(event: any) {
 
    if (event.keyCode == 9) {
      if (event.shiftKey) {
        this.behavior = 1;
      }
    } else {
      this.behavior = 0;
      if (event.key != "Backspace") {
        this.backspaceBehaviour = 0;
      }
    }
  }
 
  @HostListener('keyup', ['$event']) onKeyDown(event: any) {
    const key = event.key;
    if (key === "Backspace" || key === "Delete") {
      var prevControl: any;
      if (event.srcElement.value.length == 0 && this.backspaceBehaviour == 1) {
        event.preventDefault();
        if (this.searchType == Constants.DATECONTROL) {
          prevControl = event.srcElement.previousElementSibling;
        }
 
        while (true) {
          if (prevControl && prevControl != null) {
            if (prevControl.type === event.srcElement.type) {
              this.backspaceBehaviour = 0;
              prevControl.focus();
              return;
            }
            else {
              prevControl = prevControl.previousElementSibling;
            }
          }
          else {
            return;
          }
        }
 
      } else {
        if (event.srcElement.value.length == 0) {
          this.backspaceBehaviour = 1;
        }
 
      }
    }
 
    else if (event.srcElement.value.length == event.srcElement.maxLength && event.key != "Shift" && event.key != "Tab") {
      event.preventDefault();
      var nextControl: any;
      if (this.searchType == Constants.DATECONTROL) {
        nextControl = event.srcElement.nextElementSibling;
      }
      // Searching for next similar control to set it focus
      while (true) {
        if (nextControl && nextControl != null) {
          if (nextControl.type === event.srcElement.type) {
            if (this.behavior != 1) {
              nextControl.focus();
            }
            return;
          }
          else {
            nextControl = nextControl.nextElementSibling;
          }
        }
        else {
          return;
        }
      }
    }
    else if (event.srcElement.value.length > event.srcElement.maxLength) {
 
      event.srcElement.value = event.srcElement.value.slice(0, -1); // event.srcElement.value.substr(0, length - 1);
      var nextControl: any;
      if (this.searchType == Constants.DATECONTROL) {
        nextControl = event.srcElement.nextElementSibling;
      }
      // Searching for next similar control to set it focus
      while (true) {
        if (nextControl && nextControl != null) {
          if (nextControl.type === event.srcElement.type) {
            nextControl.focus();
            return;
          }
          else {
            nextControl = nextControl.nextElementSibling;
          }
        }
        else {
          return;
        }
      }
    }
  }

}
