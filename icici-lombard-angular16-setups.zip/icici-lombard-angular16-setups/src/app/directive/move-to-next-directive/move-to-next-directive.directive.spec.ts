import { MoveToNextDirectiveDirective } from './move-to-next-directive.directive';

describe('MoveToNextDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new MoveToNextDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
