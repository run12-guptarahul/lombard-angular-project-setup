import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[appAlphabetOnlyDirective]'
})
export class AlphabetOnlyDirectiveDirective {

  constructor() { }

  @HostListener('keydown', ['$event']) onKeydown(event: KeyboardEvent) {
    const key = event.key;

    // Allow control keys and specific keys that are always allowed
    if (['Backspace', 'Tab', 'ArrowLeft', 'ArrowRight', 'ArrowUp', 'ArrowDown', 'Delete', 'Shift', 'Control', 'Alt', 'Meta'].includes(key)) {
      return;
    }

    // Allow alphabet keys and space
    if (/^[a-zA-Z ]$/.test(key)) {
      return;
    }

    // Prevent default action for other keys
    event.preventDefault();
  }

  @HostListener('input', ['$event']) onInput(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    const sanitizedValue = inputElement.value.replace(/[^a-zA-Z ]/g, '');
    if (inputElement.value !== sanitizedValue) {
      inputElement.value = sanitizedValue;
      event.preventDefault();
    }
  }
}
