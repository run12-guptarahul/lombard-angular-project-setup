import { AlphabetOnlyDirectiveDirective } from './alphabet-only-directive.directive';

describe('AlphabetOnlyDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new AlphabetOnlyDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
