import { Directive, ElementRef, Input, OnChanges } from '@angular/core';

@Directive({
  selector: '[appDollerFormat]'
})
export class DollerFormatDirective implements OnChanges {
  @Input('appDollerFormat') number: any;

  constructor(private el: ElementRef) { }


  ngOnChanges() {
    if (this.number !== undefined && this.number !== null) {
      const formattedValue = this.formatNumber(this.number);
      // If the element is an input, set its value property
      if (this.el.nativeElement.tagName === 'INPUT') {
        this.el.nativeElement.value = formattedValue;
      } else {
        this.el.nativeElement.innerText = formattedValue;
      }
    }
  }
  // Function to format number
  private formatNumber(number: any): string {
    let num = Number(number);
    if (num >= 1000000) {
      return '$'+(num / 1000000) + 'M'; // 1 Million or more
    } else if (num >= 1000) {
      return '$'+(num / 1000) + 'k'; // 1 Thousand or more
    } else {
      return '$'+ num.toString(); // Less than 1 Thousand
    }
  }
}
