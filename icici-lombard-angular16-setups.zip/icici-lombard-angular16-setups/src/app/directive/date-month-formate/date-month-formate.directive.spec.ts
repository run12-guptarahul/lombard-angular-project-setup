import { DateMonthFormateDirective } from './date-month-formate.directive';

describe('DateMonthFormateDirective', () => {
  it('should create an instance', () => {
    const directive = new DateMonthFormateDirective();
    expect(directive).toBeTruthy();
  });
});
