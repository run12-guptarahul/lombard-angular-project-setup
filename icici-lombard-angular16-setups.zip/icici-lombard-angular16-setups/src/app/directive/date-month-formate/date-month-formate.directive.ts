import { Directive, ElementRef, Input, OnChanges } from '@angular/core';

@Directive({
  selector: '[appDateFormat]'
})
export class DateMonthFormateDirective implements OnChanges {

  @Input('appDateFormat') travelEndDate: string;

  constructor(private el: ElementRef) {}

  ngOnChanges(): void {
    this.formatDate();
  }

  private formatDate(): void {
    if (this.travelEndDate) {
      const date = new Date(this.travelEndDate);

      // Get day
      const day = date.getDate();

      // Get month abbreviation
      const monthNames = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
      const month = monthNames[date.getMonth()];

      // Format and set the content of the element
      const formattedDate = `${day} ${month}`;
      this.el.nativeElement.innerText = formattedDate;
    }
  }
}
