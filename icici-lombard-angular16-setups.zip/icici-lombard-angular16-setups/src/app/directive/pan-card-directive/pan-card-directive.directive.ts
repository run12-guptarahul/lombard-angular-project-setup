import { Directive, HostListener, ElementRef } from '@angular/core';
import { NG_VALIDATORS, Validator, AbstractControl, ValidationErrors } from '@angular/forms';

@Directive({
  selector: '[appPanCard]',
  providers: [{ provide: NG_VALIDATORS, useExisting: PanCardDirective, multi: true }]
})
export class PanCardDirective implements Validator {

  private readonly panCardPattern = /^[A-Z]{5}[0-9]{4}[A-Z]{1}$/;

  constructor(private el: ElementRef) { }

  @HostListener('input', ['$event'])
  onInputChange(event: Event): void {
    const input = this.el.nativeElement.value.toUpperCase();
    const formattedInput = this.formatPanCard(input);
    this.el.nativeElement.value = formattedInput;
  }

  validate(control: AbstractControl): ValidationErrors | null {
    const value = control.value;
    if (!value) {
      return null;
    }

    const isValid = this.panCardPattern.test(value);
    return isValid ? null : { panCard: { valid: false } };
  }

  private formatPanCard(value: string): string {
    const lettersPart = value.slice(0, 5).replace(/[^A-Z]/g, '');
    const numbersPart = value.slice(5, 9).replace(/[^0-9]/g, '');
    const lastLetter = value.slice(9, 10).replace(/[^A-Z]/g, '');

    return (lettersPart + numbersPart + lastLetter).slice(0, 10);
  }
}
