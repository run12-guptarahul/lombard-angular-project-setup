import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AlphabetOnlyDirectiveDirective } from './alphabet-only-directive/alphabet-only-directive.directive';
import { DigitOnlyDirectiveDirective } from './digit-only-directive/digit-only-directive.directive';
import { MoveToNextDirectiveDirective } from './move-to-next-directive/move-to-next-directive.directive';
import { PanCardDirective } from './pan-card-directive/pan-card-directive.directive';
import { DateMonthFormateDirective } from './date-month-formate/date-month-formate.directive';
import { ClickOutsideDirective } from './click-outside-directive/click-outside-directive';
import { DollerFormatDirective } from './dollor-format/doller-format-directive.directive';


@NgModule({
  declarations: [
    AlphabetOnlyDirectiveDirective,
    DigitOnlyDirectiveDirective,
    MoveToNextDirectiveDirective,
    PanCardDirective,
    DateMonthFormateDirective,
    ClickOutsideDirective,
    DollerFormatDirective
  ],
  imports: [
    CommonModule
  ],
  exports: [
    AlphabetOnlyDirectiveDirective,
    DigitOnlyDirectiveDirective,
    MoveToNextDirectiveDirective,
    PanCardDirective,
    DateMonthFormateDirective,
    ClickOutsideDirective,
    DollerFormatDirective
  ]
})
export class DirectiveModule { }
