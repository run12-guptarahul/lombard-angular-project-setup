import { DigitOnlyDirectiveDirective } from './digit-only-directive.directive';

describe('DigitOnlyDirectiveDirective', () => {
  it('should create an instance', () => {
    const directive = new DigitOnlyDirectiveDirective();
    expect(directive).toBeTruthy();
  });
});
