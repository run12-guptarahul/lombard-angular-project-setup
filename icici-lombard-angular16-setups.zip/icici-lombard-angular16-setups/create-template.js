const fs = require('fs')
var path = require('path');

function convertDotToDash(file) {
  var parts = file.split(".");
  return parts.slice(0, -1).join('-') + "." + parts.slice(-1)
}

console.log("Creating Sitefinity Scripts")

// EDIT THIS to change the script tag prefix location
let jsPathStage = "/docs/default-source/apps/website-chirenewal-fresh-app/stage/"
let jsPathLive = "/docs/default-source/apps/website-chirenewal-fresh-app/prod/"

// Dist directory
let distPath = 'dist/website-chirenewal-fresh-app'
let configPath = 'dist/sitefinity'

if (!fs.existsSync(configPath)) {
  fs.mkdirSync(configPath);
}

// file names for file file
let staging = configPath + "/stage.txt"
let live = configPath + "/live.txt"

let files = fs.readdirSync(distPath)

let jsFiles = []
let cssFiles = []

for (let i = 0; i < files.length; i++) {
  let file = distPath + "/" + files[i]
  let ext = path.extname(file)

  if (fs.lstatSync(file).isFile() && ext == '.js') {
    let jf = convertDotToDash(files[i]);
    jsFiles.push(jf)
  }
  if (fs.lstatSync(file).isFile() && ext == '.css') {
    let cf = convertDotToDash(files[i]);
    cssFiles.push(cf)
  }
}

let pkg = JSON.parse(fs.readFileSync('package.json'))

let filePrefix = jsPathStage + pkg.version + "/"
let sourceStaging = []
let sourceLive = []

for (let i = 0; i < jsFiles.length; i++) {
  sourceStaging.push("<script src='" + filePrefix + jsFiles[i] + "' type='module'></script>")
  sourceLive.push("<script src='" + jsPathLive + jsFiles[i] + "' type='module'></script>")
}
sourceStaging.push("<link rel='" + "stylesheet" + "' href='" + filePrefix + cssFiles[0] + "'>")
sourceLive.push("<link rel='" + "stylesheet" + "' href='" + jsPathLive + cssFiles[0] + "'>")

fs.writeFileSync(staging, sourceStaging.join('\r\n'), "utf8");
fs.writeFileSync(live, sourceLive.join('\r\n'), "utf8");

console.log("Created files ", staging, live)
